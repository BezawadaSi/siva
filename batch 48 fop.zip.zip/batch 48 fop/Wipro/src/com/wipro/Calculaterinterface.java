package com.wipro;

public interface Calculaterinterface {

	public int add(int a,int b);
	public int sub(int a ,int b);
	public int mul(int a,int b);
	
	public default int findModulo(int a ,int b) {
	 return (a%b);	
	}
	//double sqareRoot(double a);
	
}
