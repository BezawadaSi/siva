package com.wipro;
import java.util.Scanner;
public class Check_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		 System.out.print("Enter the main string: ");
		 String mainString = scanner.nextLine();
	
		 System.out.print("Enter the prefix string:\n ");
		 String prefixString = scanner.nextLine();
		
		 boolean startsWith = mainString.startsWith(prefixString);
		
		 if (startsWith) 
		 {
		      System.out.println(startsWith);
		      System.out.println("The main string starts with the prefix string." );
		 }  
		 else 
		 {
			 System.out.println(startsWith);
		     System.out.println("The main string does not start with the prefix string." );
		 }
		 scanner.close();
		

	}

}
