package com.wipro;
import java.util.Scanner;
public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int arr[] = new int[5];
   Scanner sc= new Scanner(System.in);
  System.out.println("enter arry eliments");
  for(int i=0;i<5;i++)
	  arr[i]=sc.nextInt();
  
  int sum=0;
  System.out.println(" array elements");
  for (int i=0;i<5;i++)
	  if (arr[i] % 2== 0)
		  System.out.println(arr[i]);
	  else
		  sum =sum + arr[i];
  System.out.println(sum);
	  
  }

	}

