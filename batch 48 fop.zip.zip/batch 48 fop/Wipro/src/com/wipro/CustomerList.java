package com.wipro;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomerList  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		Customer1 c1= new Customer1(23,"bhargav","hyderabad","Telangana");
		Customer1 c2= new Customer1(25,"siva","ongole","AP");
		Customer1 c3= new Customer1(56,"krishna","Delhi","Delhi");
		Customer1 c4= new Customer1(15,"bezawada","bengalore","Karnataka");
		Customer1 c5= new Customer1(86,"naveen","patna","Bihar");
		
		Customer1 c6= new Customer1(231,"sai","hyderabad","Telangana");
		Customer1 c7= new Customer1(255,"dhruv","ongole","AP");
		Customer1 c8= new Customer1(564,"suvidh","Delhi","Delhi");
		Customer1 c9= new Customer1(156,"dhusanth","bengalore","Karnataka");
		Customer1 c10= new Customer1(864,"nishvith","patna","Bihar");
		
		ArrayList<Customer1> customerList=new ArrayList<Customer1>();
		customerList.add(c1);
		customerList.add(c2);
		customerList.add(c3);
		customerList.add(c4);
		customerList.add(c5);
		customerList.add(c6);
		customerList.add(c7);
		customerList.add(c8);
		customerList.add(c9);
		customerList.add(c10);
		
		System.out.println(customerList);
		System.out.println("customer list after sortin");
		Collections.sort(customerList);
		
		for(Customer1 cust: customerList)
			System.out.println(cust);
		
		customerList.sort(new cityComparator().thenComparing(new NameComparator()));
		for(Customer1 cust1:customerList)
			System.out.println();
		customerList.sort(new cityComparator()
				.thenComparing(new NameComparator()
				.thenComparing(new IdComparator())));
		
		
	}

}
