package com.wipro;
import java.util.Scanner;
public class Calculater {

	public static void main(String[] args) {
		int choice;
		int num1,num2;
		Scanner sc= new Scanner(System.in);	
		num1=sc.nextInt();
		num2=sc.nextInt();	
		do {
		System.out.println("CALCULATOR MENU....");
		System.out.println("1:add\n2:sub\n3:mul\n4:div");
		choice=sc.nextInt();
		switch(choice) {
		case 1: System.out.println(num1+num2);
		break;
		case 2:System.out.println(num1-num2);
		break;
		case 3: System.out.println(num1*num2);
		break;
		case 4: System.out.println(num1/num2);
		break;
		}	
	    }while(choice<=4);
		System.out.println("THANK YOU");
	}

	

}
