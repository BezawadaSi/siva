package com.wipro;

import java.util.Arrays;

public class Student {
	String name;
	int id;
	int marks[];
	
	
	public Student() {
		System.out.println("From default constructor");
	}


	public Student(String name, int id, int[] marks) {
		super();
		this.name = name;
		this.id = id;
		this.marks = marks;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int[] getMarks() {
		return marks;
	}


	public void setMarks(int[] marks) {
		this.marks = marks;
	}


	@Override
	public String toString() {
		return "Student [name=" + name + ", id=" + id + ", marks=" + Arrays.toString(marks) + "]";
	}
	
	
	
	

}