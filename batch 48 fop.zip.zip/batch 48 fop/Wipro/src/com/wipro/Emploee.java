package com.wipro;

public class Emploee extends Peroson {
	@Override
	public String toString() {
		return "Emploee [empSal=" + empSal + ", compnay=" + compnay + ", name=" + name + ", age=" + age + ", mobile="
				+ mobile + ", email=" + email + ", address=" + address + "]";
	}
	private double empSal;
	private String compnay;
	public Emploee() {
		super();
	}
	
	public Emploee(String name,int age,String mobile,String emial,String address,double empSal, String compnay) {
		super();
		this.empSal = empSal;
		this.compnay = compnay;
	}

	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	public String getCompnay() {
		return compnay;
	}
	public void setCompnay(String compnay) {
		this.compnay = compnay;
	}
	

}
