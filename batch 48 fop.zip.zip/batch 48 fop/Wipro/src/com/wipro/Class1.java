package com.wipro;

public class Class1 implements Interface1 {

	public void printMsg() {
		System.out.println("class1");

	}

}
