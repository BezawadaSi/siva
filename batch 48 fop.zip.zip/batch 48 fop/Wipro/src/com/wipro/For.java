package com.wipro;
import java.util.Scanner;
public class For {

	public static void main(String[] args) {
		int a,b,count=0;
		Scanner s= new Scanner(System.in);
		System.out.println("enter  a value");
		a=s.nextInt();
		for (b=1;b<=a;b++)
		{
		if (a%b == 0) {
			System.out.println(b);
		count++;}
		}
		if(count == 2)
		System.out.println("it is prime number");
		else
		System.out.println("is not prime number");
		}
	/*
	 * for (b= 2 ; b<= a/2;b++)
	 * {
	 * if (a%b == 0) 
	 * {
			System.out.println(b);
		count++;
		break;
		}
		}
	 * if (count == 0)
	 */
		
	}


