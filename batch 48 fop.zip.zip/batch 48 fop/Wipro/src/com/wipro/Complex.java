package com.wipro;

public class Complex {
	int real;
	int img;
	public Complex(int real, int img) {
		super();
		this.real = real;
		this.img = img;
	}
	public Complex()
	{
		super();
	}
	@Override
	public String toString() {
		return "Complex [real=" + real + ", img=" + img + "]";
	}
	
	

}
