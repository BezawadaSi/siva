package com.wipro;

public class InheritanceMain {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
 
		Peroson p = new Peroson("Siva",43,"999999999","bsiva4550@gmail.com","hyderabad");
		Emploee e = new Emploee("Amit",45,"88888888","amit@gmail.com","hyderabad",50000,"wipro");
		String skills[]= {"java","spring","hibernate"};
		Programer pr=new Programer("AISHYAA",23,"8585857","Mumbai","aishya98@gmail.com","java",skills);
		
		System.out.println(p);
		System.out.println(e);
		System.out.println(pr);

	}

}
