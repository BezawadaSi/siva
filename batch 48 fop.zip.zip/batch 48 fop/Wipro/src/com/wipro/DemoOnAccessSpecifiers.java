package com.wipro;

public class DemoOnAccessSpecifiers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
