package com.wipro;

public class Lexicographically {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "siva krishna";
        String str2 = "Bezawada";
        System.out.println("String 1: " + str1);
        // Print the second string.
        System.out.println("String 2: " + str2);
        int result = str1.compareTo(str2);
        if (result < 0) {
            // If the result is less than 0, print that the first string is less than the second.
            System.out.println("\"" + str1 + "\"" +  " is less than " +  "\"" + str2 + "\"");
            System.out.println("First string comes before the second string lexicographically.");  
               
        } else if (result == 0) {
            // If the result is 0, print that the first string is equal to the second.
            System.out.println("\"" + str1 + "\"" +  " is equal to " + "\"" + str2 + "\"");
            System.out.println("Both strings are lexicographically equal.");  
                
        } else { // if (result > 0)
            // If the result is greater than 0, print that the first string is greater than the second.
            System.out.println("\"" + str1 + "\"" +  " is greater than " + "\"" + str2 + "\"");
            System.out.println("First string comes after the second string lexicographically.");  
                
        }
    }

	}


