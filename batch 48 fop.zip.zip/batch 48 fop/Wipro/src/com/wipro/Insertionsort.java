package com.wipro;

public class Insertionsort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int j = 0,ele;
		int [] arr = {67,25,35,3,7,1,58,69,76,89,11};
	    for(int i=1;i<arr.length;i++)
	    {
	      ele =arr[i];
	      j=i-1;
          while(j>=0&&arr[j]>ele)
	      {
	    	 
	      
	    	  arr[j+1]=arr[j];
	    	  j=j-1;
	      }
	      arr[j+1]=ele;
	
	    }
	    for (int i:arr)
	    	System.out.println(i);
	}

}
