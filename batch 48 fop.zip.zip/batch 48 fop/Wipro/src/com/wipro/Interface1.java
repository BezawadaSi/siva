package com.wipro;

public interface Interface1 {
   
	public default void printMsg(){
		System.out.println("hello");
	}

}
