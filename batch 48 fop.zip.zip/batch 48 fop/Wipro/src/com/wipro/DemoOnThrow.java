package com.wipro;

public class DemoOnThrow {

	public static void login(String uname,String pwd) {
		try {
			
		if(uname.equals("siva")&& pwd.equals("12345")) {
			System.out.println("user autnticated");
		}
		else
			throw new USerNotFoundException("Exception occured,no user");
		
	}
		catch(USerNotFoundException e) {
			System.out.println(e);
		}
	}
	public static void main(String[] args)throws USerNotFoundException  {
		
		
		// TODO Auto-generated method stub
        String uname="sibva";
        String pwd="12345";
        login(uname,pwd);
        
		
	}

}
