package com.wipro;

public class Calculater1 implements Calculaterinterface ,ScientificCalculaterInterface{
	{
}

	@Override
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}

	@Override
	public int sub(int a, int b) {
		// TODO Auto-generated method stub
		return a-b;
	}

	@Override
	public int mul(int a, int b) {
		// TODO Auto-generated method stub
		return a*b;
	}

	@Override
	public double Power(double a, double b) {
		// TODO Auto-generated method stub
		return Math.pow(a, b);
	}
	@Override
	public double sqareRoot(double a) {
		// TODO Auto-generated method stub
		return Math.sqrt(a);
	}

	
}
