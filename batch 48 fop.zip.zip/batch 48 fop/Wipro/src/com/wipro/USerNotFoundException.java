package com.wipro;

public class USerNotFoundException extends Exception {

	public USerNotFoundException(String s) {
		// TODO Auto-generated constructor stub
		System.out.println(s);
	}

	
}
