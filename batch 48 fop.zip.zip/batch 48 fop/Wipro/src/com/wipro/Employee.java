/*package com.wipro;

public class Employee {
	
	private String empName;
	private int empId;
	private double empSal;
	private String companay;
	public Employee()
	{
		super();
	}
	public Employee(String empName,int empId)
	{
		super();
		this.empName=empName;
		this.empId=empId;
		this.empSal=empSal;
		this.companay="wipro";
		
	}
	public Employee(String empName,int empId,double empSal)
	{
		super();
		this.empName=empName;
		this.empId=empId;
		this.empSal=empSal;
		this.companay="wipro";
		
	}
	public Employee(String empName,int empId,double empSal,String compnay)
	{
		super();
		this.empName=empName;
		this.empId=empId;
		this.empSal=empSal;
		this.companay=company;
		
	}
	public String getCompanay() {
		return companay;
	}
	public void setCompanay(String companay) {
		this.companay = companay;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	//@Override
	//public String toString() {
	//	return "Employee [empName=" + empName + ", empId=" + empId + ", empSal=" + empSal + "]";
	//}
	@Override
	public String toString() {
		return "Employee [empName=" + empName + ", empId=" + empId + ", empSal=" + empSal + ", companay=" + companay
				+ "]";
	}
}*/
package com.wipro;
 
public class Employee {
	
	/*
	 * private String empName;
	 */
	private int empId;
	private double empSal;
	private String company;
	private String empName;
	public Employee() {
		super();//parent class Object constructor,to represent parent class
		//super keyword is used
	}
	
	
	public Employee(String empName, int empId) {
		super();
		this.empName = empName;
		this.empId = empId;
		this.empSal=25000;
		this.company="Wipro";
		
	}
	public Employee(String empName, int empId, double empSal) {
		super();
		this.empName = empName;
		//when we want to address current reference use this keyword
		this.empId = empId;
		this.empSal = empSal;
		this.company="Wipro";//default value for company
	}
	
	
	
	public Employee(String empName, int empId, double empSal, String company) {
	super();
	this.empName = empName;
	this.empId = empId;
	this.empSal = empSal;
	this.company = company;
	}
	//constructor overloading is a concept where a constructor defined with multiple def.
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	
	
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
@Override
	public String toString() {
		return "Employee [empName=" + empName + ", empId=" + empId + ", empSal=" + empSal + ", company=" + company
				+ "]";
	}
} 
	

 
