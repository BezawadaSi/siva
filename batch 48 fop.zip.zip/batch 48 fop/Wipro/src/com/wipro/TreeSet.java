package com.wipro;

public class TreeSet {

	public static void main(String[] args) {
//		TreeSet<String> ts = new TreeSet<String>();
//		ts.add("deebyanshu");
//		ts.add("amit");
//		ts.add("raj");
//		ts.add("anand");
//		System.out.println(ts);// treeset implements sortedset,navigableset
//
//		System.out.println("===========");
//		Iterator<String> itr = ts.iterator();// the iterator points to before first elements
//		while (itr.hasNext())
//			System.out.println(itr.next());
//
//		System.out.println("===========");
//		itr = ts.descendingIterator();// the iterator points after last element
//		while (itr.hasNext())
//			System.out.println(itr.next());
//
//		HashSet<Integer> hs = new HashSet<Integer>();// has set is not sorted
//		hs.add(77);
//		hs.add(45);
//		hs.add(89);
//		hs.add(33);
//		System.out.println(hs);
//		TreeSet<Integer> ts1 = new TreeSet<Integer>(hs);// sorted set
//		System.out.println(ts1);
//		NavigableSet<Integer> nv = new TreeSet<Integer>(hs);
//		System.out.println(ts1);
//		System.out.println(nv.descendingSet());
//
//		ts1.add(88);
//		ts1.add(56);
//		ts1.add(31);
//		System.out.println(ts1);
//
//		System.out.println(ts1.floor(75));// 56
//		System.out.println(ts1.ceiling(75));// 77
//		System.out.println(ts1.pollFirst());
//		System.out.println(ts1.pollLast());
//		System.out.println(ts1);
//		System.out.println(ts1.tailSet(50));
//		System.out.println(ts1.headSet(50));

/*		Customer1 c1 = new Customer1(23, "Bhargav", "hyd", "Telangana");
		Customer1 c2 = new Customer1(24, "Barath", "chenni", "Tamilnadu");
		Customer1 c3 = new Customer1(25, "Chinnu", "Delhi", "Delhi");
		Customer1 c4 = new Customer1(26, "Amit", "bangalore", "Karnatka");
		Customer1 c5 = new Customer1(27, "Druv", "hyd", "Telangana");

		Customer1 c6 = new Customer1(231, "Bhargav", "hyd", "Telangana");
		Customer1 c7 = new Customer1(112, "Barathsen", "chenni", "Tamilnadu");
		Customer1 c8 = new Customer1(101, "Chinnusri", "Delhi", "Delhi");
		Customer1 c9 = new Customer1(231, "AmitKumar", "bangalore", "Karnatka");
		Customer1 c10 = new Customer1(213, "Druvsh", "hyd", "Telangana");
		Customer1 c11 = new Customer1(231, "Bhargav", "hyd", "Telangana");
		Customer1 c12 = new Customer1(231, "Bhargav", "hyd", "Telangana");

		TreeSet <Customer1> customerTreeSet = new TreeSet <Customer1>();
		customerTreeSet.add(c1);
		customerTreeSet.add(c2);
		customerTreeSet.add(c3);
		customerTreeSet.add(c4);
		customerTreeSet.add(c5);
		customerTreeSet.add(c6);
		customerTreeSet.add(c7);
		customerTreeSet.add(c8);
		customerTreeSet.add(c9);
		customerTreeSet.add(c10);
		customerTreeSet.add(c11);
		customerTreeSet.add(c12);

		for (Customer cust : customerTreeSet)
			System.out.println(cust);
	}

}*/
	}
}