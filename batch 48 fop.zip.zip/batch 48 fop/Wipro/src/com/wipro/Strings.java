package com.wipro;

import java.util.LinkedList;

public class Strings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String s="siva Krishna";
		//String s1="Bezawada";
		//System.out.println("*********");
		//System.out.printf("%15s",s);
		//System.out.printf("%15s,%s",s,s1);
		/*int sum=0;
		for(int i=0;i<3;i++)
		{
			sum+=(i%2==0)?i:-i;
		}
		System.out.println("result =" + sum);
		int counter= 7;
		while (counter >= 4)
		{
			System.out.println(counter +"");
			counter = counter -1;
		}
     System.out.println();*/
		int num1=10,num2=14,num3=15;
		System.out.println("value of num1 :" + num1);
		if ((++num2>num3)&&(num1>num3))
		{
			System.out.println("value of num3: "+ num3);
		}
		System.out.println("value of num2 :" + num2);

		/*StringBuffer sb=new StringBuffer("Welcome");
		sb.insert(2, "pradeep");
		System.out.println(sb);
		int var =10;
		int var2= var++;
		System.out.println(var2);
		System.out.println(var);
		String s="hello.java!";
		int length=s.length();
		String subString=s.substring(0,5);
		System.out.println(length);
		System.out.println(subString);*/
		/*String name="sonoo";
		String sf1=String.format("name is %s",name);
		String sf2=String.format("value is %f",32.33434);
		String sf3=String.format("value is %32.12f",32.33434);
		System.out.println(sf1+" ");
		System.out.println(sf2+" ");
		System.out.println(sf3);
		int x=5,y=7,z=10;
		if(x>y||z>x&&++y==z--)
		{
			x++;
		}
		else {
			z++;
		}
		System.out.println(y);
		int a[]= {0,2,4,1,3};
		for(int i=0;i<a.length;i++) {
			a[i]=a[(a[i]+3)%a.length];
		}
	System.out.println(a[1]);*/
		LinkedList<String> babies = new LinkedList<>();

		babies.add("Moms");

		babies.add("Dad");

		System.out.println("Initial LinkedList " + babies);

		babies.remove(1);

		babies.add(1, "For");

		System.out.println("After the Index Removal " + babies);

		System.out.println("After the Object Removal " + babies);

	
	}

}
