package com.wipro;

public class Admin extends User {
	private String previlage;
	public void display() {
		this.previlage="read,write,update";
		System.out.println(previlage);
	}


}
