package com.wipro;

public class Class3 implements Interface1,Interface2{

	@Override
	public void printMsg() {
		// TODO Auto-generated method stub
		System.out.println("From Print mesg");
	}
	

}
