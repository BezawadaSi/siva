package com.wipro;


import java.util.Scanner;


public class DemoOnArrayOp {
	
	//public static int arr[]= new int[6];
	public static int arr[]= {0,0,0,0,0};
    public static void insert() 
    {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("enter pos and element to insert:");
    	System.out.println("Note: 0 can not be an element");
    	int pos=sc.nextInt();
    	int ele=sc.nextInt();
    	
    	if(pos<=arr.length)
    	{
    	if(arr[pos-1]==0)
    		arr[pos-1]=ele;
    	else
    	{
    		
    		int index=arr.length-1;
    		while(index>=pos-1) {
    			arr[index]=arr[index-1];
    			index--;
    		}
    		arr[pos-1]=ele;
    	}
    	
    	}
    	else 
    	{
    		System.out.println("Position is out of bounds");
    	}
    	retrive();
    }
    public static void delete() {
    	int temp;
    	Scanner sc=new Scanner(System.in);
    	System.out.println("enter pos  to delete:");
    	int pos=sc.nextInt();
    	
        if(pos==arr.length-1)
        {
        	temp=arr[pos-1];
        	
           if(pos==arr.length)
        	arr[pos-1]=0;
           else if(arr[pos-1]==0) {
        	   System.out.println("no element to delete");
           }
        else 
        {
        
        	int index=pos-1;
        	temp=arr[pos-1];
        	int temp1=arr[pos-1];
        	while(index<arr.length-1)
        	{
        		arr[index]=arr[index+1];
        		index++;
        	}
        	System.out.println(temp1 + "got deleted");
        }
        
    	
        }
        retrive();
    }
    public static void retrive()
    {
    	System.out.println("array elements:");
	   for(int i:arr)
		   System.out.println(i);
		
    }
    public static void update() 
    {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("enter pos and element to update:");
    	int pos=sc.nextInt();
    	int ele=sc.nextInt();
    	arr[pos-1]=ele;
    	retrive();
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1.insert 2.delete 3.retrive 4.update
		
		int choice;
		Scanner sc=new Scanner(System.in);
		do {
			System.out.println("1.insert 2.delete 3.retrive 4.update");
			System.out.println("enter your choice: ");
			choice=sc.nextInt();
			switch(choice) {
			case 1: insert();
			break;
			case 2:delete();
			break;
			case 3:retrive();
			break;
			case 4: update();
			break;
			default: System.out.println("invalid choice");
			
			}
		}while(choice<=4);
		sc.close();
	}

}

