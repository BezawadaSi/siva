package com.wipro;

import java.util.Arrays;

public class Programer extends Peroson{
	
String domain;
String skills[];
public Programer() {
	super();
}
public Programer(String name,int age,String mobile,String email,String address,String domain, String[] skills) {
	super();
	this.domain = domain;
	this.skills = skills;
}
public String getDomain() {
	return domain;
}
public void setDomain(String domain) {
	this.domain = domain;
}
public String[] getSkills() {
	return skills;
}
public void setSkills(String[] skills) {
	this.skills = skills;
}
@Override
public String toString() {
	return "Programer [domain=" + domain + ", skills=" + Arrays.toString(skills) + ", name=" + name + ", age=" + age
			+ ", mobile=" + mobile + ", email=" + email + ", address=" + address + "]";
}


}
