package com.wipro;

public class User {
	protected String username;
	protected String pwd;
	public void display() {
		this.username="sudhi";
		this.pwd="344";
		System.out.println(username+" "+pwd);
	}


}
