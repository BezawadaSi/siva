package com.wipro;

public class OverridingDemo {
	public static void main(String [] args) {
		User u=new User();
		/*Customer c=new Customer();
		Admin a= new Admin();*/
		u.display();
		//c.display();
		u=new Customer();
		u.display();
		u=new Admin();
		u.display();
		//a.display();
	}


}
