package com.wipro;
import java.util.Scanner;
public class Twice_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner = new Scanner(System.in);

	        System.out.println("Enter a string:");
	        String input = scanner.nextLine();

	        String repeatedString = repeatCharactersTwice(input);

	        System.out.println("Original string: " + input);
	        System.out.println("String with every character repeated twice: " + repeatedString);

	        scanner.close();
	    }

	    public static String repeatCharactersTwice(String str) {
	        StringBuilder repeated = new StringBuilder();
	        for (int i = 0; i < str.length(); i++) {
	            char c = str.charAt(i);
	            repeated.append(c).append(c); // Append each character twice
	        }
	        return repeated.toString();
	    }
}


