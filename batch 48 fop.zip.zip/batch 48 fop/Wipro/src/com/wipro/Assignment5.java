package com.wipro;

public class Assignment5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int[] intArray = new int[5];
		//System.out.println(intArray[0]);
		System.out.println(" siva");
		int[] intArray = new int[8];
        double[] doubleArray = new double[8];
        float[] floatArray = new float[8];
        long[] longArray = new long[8];
        short[] shortArray = new short[8];
        byte[] byteArray= new byte[8];
        boolean[] booleanArray = new boolean[8];
        char[] charArray = new char[8];
        String[] stringArray = new String[8];
        Object[] objectArray = new Object[8];
        System.out.println("int Array: " + intArray[0]);
        System.out.println("double Array: " + doubleArray[0]);
        System.out.println("Float Array: " + floatArray[0] );
        System.out.println("long Array: " + longArray[0] );
        System.out.println("short  Array: " + shortArray[0] );
        System.out.println("byte Array: " + byteArray[0] );
        System.out.println("boolean Array: " + booleanArray[0]);
        System.out.println("char Array: " + charArray[1]);
        System.out.println("string Array: " + stringArray[0]);
        System.out.println("object Array: " + objectArray[0]);
	}

}
