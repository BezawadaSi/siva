package com.wipro;

public class Elementsearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] arr = {1,58,55 ,87,9,8,89,67,56};
		 int key= 58;
		 int i;
		 for (i=0;i<arr.length;i++)
		 {
			 if (key == arr[i])
			 {
				 System.out.println("Element found "+ (i+1));
				 break;
			 }
		 }
		 if (i== arr.length)
		 {
			 System.out.println("element not founf");
		 }
	}

}
