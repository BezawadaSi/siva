package com.wipro;

public class Binarysearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] arr = {11,25,35,48,58,69,76,89};
	    int key=76;
		int mid,low =0,high=arr.length-1;
		while(low<=high)
		{
			mid=(low+high)/2;
			if(arr[mid]== key)
			{
				System.out.println("element found");
				break;
			}
			else if(arr[mid]<key)
				    low = mid+1;
			else 
				high=mid-1;
		}
		if(low >high)
		{
			System.out.println("element not found");
		}
	}

}
