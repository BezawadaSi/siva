package com.wipro;

public class Customer extends User {
	private String address;
	public void display() {
		this.address="hyd";
		System.out.println(address);
	}

}
