package com.wipro;

import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Spliterator;

public class DemoOnSets {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<Integer> hs = new HashSet<Integer>();
		hs.add(80);
		hs.add(00);
		hs.add(78);
		hs.add(54);
		System.out.println(hs);
	    hs.add(00);
	    hs.add(80);
	    System.out.println(hs);
	    hs.add(null);
	    hs.add(null);
	    System.out.println(hs);
	    //for(int i=0;i<hs.size();i++)
	    //	System.out.println(hs);
	    //Spliterator<Integer> itr = hs.spliterator();
	    Iterator<Integer>itr1 = hs.iterator();
	    while(itr1.hasNext()) {
	    	int i=itr1.next();	    	
	    	System.out.println(i);
	        
	    	if(i==80)
	        	hs.remove(80);
	    }
	    System.out.println("using enums");
	    Enumeration<Integer> enum1 =Collections.enumeration(hs);
	    while(enum1.hasMoreElements()) {
	    	int i=enum1.nextElement();
	    	System.out.println(i*10);
	   // 	if(i==80)
	    //		enum1.remove(80);
	    	
	    }
	    	//System.out.println(enum1.nextElement()*10);
	    
	}

}
