package com.wipro;

public class Sum_Max_Array {
	public static void main(String[] args) {  
     
        int [] arr = {10,5,89,2,45,0,5,923};  
        int sum = 0;  
        
        for (int i = 0; i < arr.length; i++) 
        {  
           sum = sum + arr[i];  
        }  
        System.out.println("Sum of all the elements of an array: " + sum);
        
        
        int max = arr[0];  
       
        for (int i = 0; i < arr.length; i++)
        {  
           
           if(arr[i] > max)  
               max = arr[i];  
        }  
        System.out.println("Largest element present in given array: " + max);  
    }  
}  


