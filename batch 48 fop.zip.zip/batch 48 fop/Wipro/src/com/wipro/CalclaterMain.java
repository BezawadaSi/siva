package com.wipro;

public class CalclaterMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CalculaterOverloading ac= new CalculaterOverloading();
		ac.add(56,78);
		ac.add(42,53,56);
		ac.add(1,22,55,45);
		
		ac.add(67.56,85.25);
		ac.add(5f, 8f);
		
		ac.add("siva", "Bezawada");
		
		ac.add(22552,4532145);
		ac.add(21, 222225555);
		ac.add(1,25,123654789);
		ac.add(565485,52,3);
		
		Complex c1= new Complex(5,6);
		Complex c2= new Complex();
		ac.add(c1, c2);

	}

}
