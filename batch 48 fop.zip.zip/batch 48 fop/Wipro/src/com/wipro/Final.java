package com.wipro;

public class Final {
	public String name="Bezawada";
	public void sayHello()
	{
		System.out.println("final class");
	}

}
