package com.wipro;

public class Reverse_String {

public static void main(String[] args) {
	
	String original = "Techademy";
    char[] charArray = original.toCharArray();
    System.out.print("Reversed string: ");
	for (int i = charArray.length - 1; i >= 0; i--) 
	{
		System.out.print(charArray[i]);
	}
}
}