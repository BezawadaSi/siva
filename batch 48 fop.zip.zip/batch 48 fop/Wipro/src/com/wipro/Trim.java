package com.wipro;
import java.util.Scanner;
public class Trim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a string:");
        String input = scanner.nextLine();

        String trimmedString = input.trim();

        System.out.println("Original string: \"" + input + "\"");
        System.out.println("String after trimming whitespace: \"" + trimmedString + "\"");

       // scanner.close();
    }
}

