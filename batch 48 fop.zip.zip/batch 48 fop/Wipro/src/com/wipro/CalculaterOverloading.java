package com.wipro;

public class CalculaterOverloading {
	public void add(int a,int b) {
		System.out.println(a+b);
	}
	public void add(int a ,int b,int c) {
		System.out.println(a+b+c);
	}
	public void add(int a,int b,int c,int d) {
		System.out.println(a+b+c+d);
	}
	public void add(float f1,float f2) {
		System.out.println(f1+f2);
	}
	public void add(double d1,double d2) {
		System.out.println(d1+d2);
	}
	public void add(String s1,String s2) {
		System.out.println(s1+s2);
	}
	public void add(Complex c1,Complex c2) {
		Complex c=new Complex();
		c.real=c1.real+c2.real;
		c.img=c1.img+c2.img;
		System.out.println(c);
	}
	public void add(int a,double d) {
		System.out.println(a+d);
	}
	public void add(short s,long l,int i) {
		System.out.println(s+l+i);
	}
	public void add(long l,int i,Short s) {
		System.out.println(l+i+s);
	}
	

}
