package com.wipro;
import java.util.Scanner;
public class Index_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the main string:");
        String mainString = scanner.nextLine();

        System.out.println("Enter the starting index:");
        int startIndex = scanner.nextInt();

        System.out.println("Enter the ending index:");
        int endIndex = scanner.nextInt();

        if (startIndex < 0 || endIndex > mainString.length() || startIndex > endIndex) {
            System.out.println("Invalid input indices.");
        } else {
            String substring = mainString.substring(startIndex, endIndex);
            System.out.println("Substring between position " + startIndex + " and " + endIndex + ": " + substring);
        }

        scanner.close();
    }
}
