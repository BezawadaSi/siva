package com.wipro;

public class DemoOnFinalClass extends Final{
    @Override
	public void sayHello() {
		System.out.println("from child class");
	}
	public static void main(String[] args) {
		DemoOnFinalClass dof=new DemoOnFinalClass();
		dof.sayHello();
		dof.name="siva";
	}

	
}
