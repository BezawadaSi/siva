package com.wipro;

import java.util.StringJoiner;

public class DemoOnStrings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       /* String str="hello";
        String s1="hello";
      //  System.out.println(str);
        System.out.println(s1==str);
        System.out.println(str.equals(s1));
        String myname=new String ("siva");
        String firstname= new String("siva");
        String str1="siva";
        System.out.println(myname==firstname);
        System.out.println(myname.equals(firstname));
        System.out.println(myname==str1);//address check
        System.out.println(myname.equals(str1));//value check
        */
		String s="hello";
		System.out.println(s.length());
		System.out.println(s.charAt(4));
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
		System.out.println(s+"world");
		System.out.println(s.concat("world"));
		char[] ch= {'s','i','v','a'};
		System.out.println(s.copyValueOf(ch));
		String s1="i love india";
		System.out.println(s1.contains("india"));
		System.out.println(s1.endsWith("a"));
		String s2[]=s1.split(" ");
		for (String i:s2)
		{
			System.out.println(i);
		}
		StringBuffer sbf = new StringBuffer("hello world");
		System.out.println(sbf);
		sbf.append("  welcome to wipro");
		System.out.println(sbf);
		// string buffer and bildeer are mutable
		//Strig buffer is a thread safe,it is a syn
	    s="siva";
	    
	    sbf=new StringBuffer(s);
		System.out.println(sbf.reverse());
		
		
		String myString[]= {"apple","banana","mango","orange"};
		String finalString="";
		for(int i=0;i<myString.length;i++) {
		
			finalString=finalString+myString[i]+ " ,";
		
	}
	    System.out.println(finalString);
		System.out.println("******************");
        
		StringJoiner sj=new StringJoiner(" ,");
		for(int i=0;i<=myString.length;i++) {
			sj.add(myString[i]);
		    System.out.println(sj.hashCode());
	    }
	    System.out.println(sj);
	   
	
	}
}
