package com.wipro;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Stack;
import java.util.Vector;

public class DemoOnArrayList {
   
	private static final String object = null;

	public static void main(String[] args) {
		/*
		ArrayList alist=new ArrayList();
		int arr[]=new int [5];
		
		arr[0]=45;
		alist.add(56);
		alist.add("siva");
		alist.add(78.8f);
		alist.add(true);
		alist.add(56.123);
		System.out.println(alist);
		int i=90;
		Integer iobj=new Integer(i); 
        iobj=i;//autoboxing covertinng a primitive to its associated wrapper objects ,by jvm 
        
        int num;
        num=iobj;// unboxing convertg a obj to its primitve data types,by jvm
        
       
		// list interface follows insertion order the way it is added ,will retreve at the same po.
        for(int i =0;i<alist.size();i++) 
        	System.out.println(alist.get(i));
        ArrayList<Integer> list=new ArrayList<Integer>();
       // ArrayList<Emploee> emplist=new ArrayList<Emploee>();
        //List can add duplicate elements
        list.add(89);
        list.add(78);
        list.add(67);
        list.add(89);
        list.add(55);
        list.add(78);
        list.add(67);
        list.add(89);
        list.add(89);
        for (int i: list)
        	System.out.println(i);
       System.out.println(list.contains(89));
       list.add(4,789);
       for (int i: list)
       	System.out.println(i);
       System.out.println("****////***///***////");
   //    list.remove(4);
    //   for (int i: list)
    //      	System.out.println(i);
     // System.out.println("****////*****///***");
    // System.out.println(list.indexOf(89));
     //  System.out.println(list.lastIndexOf(89));
    //   ArrayList<Integer> newlist = new ArrayList<Integer>();
    //   newlist.add(89);
    //   newlist.add(78);
    //   newlist.add(67);
    //   newlist.add(49);
   //    System.out.println(list.equals(newlist));
    //   ArrayList<Integer> clonedList = (ArrayList<Integer>) list.clone();
       
    //   System.out.println("cloned List");
    //   for (int i: clonedList)
    //     	System.out.println(i);
    //   System.out.println(list.hashCode());
     //  System.out.println(clonedList.hashCode());
       
    //   clonedList.add(678);
    //   System.out.println("cloned list after eleement add");
    //   for (int i: clonedList)
    //    	System.out.println(i);
    //   System.out.println("****////****/////***");
    //   for (int i: list)
    //   	System.out.println(i);
    //   System.out.println(list.hashCode());
    //   System.out.println(clonedList.hashCode());
   
    //   Scanner sc = new Scanner(System.in); 
       
       //list.add(sc.nextInt());
       
     //  list.addAll(clonedList);
     //  list.add(null);
     //  list.add(null);
     //  list.add(null);
     //  System.out.println("+++++++++++++++++++++++++++");
     //  System.out.println(list);
       //int[] arr2=new int[list.size()];
       
    //   Object[] arr1=list.toArray();
    //   System.out.println(arr1.length);
    //   System.out.println(arr1[4]);
     
       
     /*  LinkedList<String> fruitList=new LinkedList<String>();
       fruitList.add("apple");
       fruitList.add("mango");
       fruitList.add("banana");
       fruitList.add("grapes");
       fruitList.addFirst("pineapple");
       fruitList.addLast("watermelon");
       System.out.println(fruitList);
       System.out.println("%%%%%% using iterator $$$$$$$");
       Iterator<String>itr = fruitList.iterator();
       fruitList.add("strawberry");
       while(itr.hasNext())
       {
    			   
    	   System.out.println(itr.next());
       }
       Collections.sort(fruitList);
       System.out.println(fruitList);
       */
       Vector<Integer> v= new Vector<Integer>();
       System.out.println(v.capacity());
       v.add(56);
       v.add(56);v.add(56);v.add(56);v.add(56);v.add(56);v.add(56);v.add(56);v.add(56);v.add(56);
       System.out.println(v.capacity());
       v.add(54);
       System.out.println(v.capacity());
       Stack<Integer> s= new Stack<Integer>();
       s.push(45);
       s.push(58);
       s.push(98);
       
       //System.out.println(s.pop());
       System.out.println(s.pop());
       System.out.println(s.peek());
       s.push(55);
       s.push(85);
       s.push(96);
       System.out.println(s);
       System.out.println(s.search(96));
       System.out.println(s.search(50));;
       Enumeration<Integer> e=v.elements();
       while(e.hasMoreElements()) {
    	   int i=e.nextElement();
    	   if(i==156)
    		   v.remove(i);
    	   System.out.println(v);
       }
	}
}
