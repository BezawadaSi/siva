package com.wipro;
import java.util.Scanner;
public class Luckeynumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner siva= new Scanner(System.in);
		
		int num =siva.nextInt();
		int r,sum=0;
		while (num > 0 || sum >9)
		{ 
			if(num ==0)
			{
				num = sum;
				sum =0;
			}
			r= num%10;
			sum=sum+r;
			num =num/10;
		}
		System.out.println(sum);

	}

}
