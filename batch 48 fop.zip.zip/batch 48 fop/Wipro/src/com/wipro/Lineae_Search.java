package com.wipro;

public class Lineae_Search {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] arr = {11,25,35,48,58,69,76,89};
	    int key=48;
	    int result = lineaesearch(arr,key);
	    
	    if(result!=1)
	    {
	    	System.out.println("Element found at index :" + result);
	    }
	    	else 
	    	{
	    		System.out.println("element not found");
	    	}
	    }


	private static int lineaesearch(int[] arr, int key) {
		// TODO Auto-generated method stub
		for (int i=0;i<arr.length;i++)
		{
			if(arr[i]== key)
			{
				return i;
			}
		}
		
		
		
		return 0;
	}

}
