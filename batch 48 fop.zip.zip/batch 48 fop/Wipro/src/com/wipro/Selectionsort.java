package com.wipro;

public class Selectionsort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int temp ;
		int [] arr = {67,25,35,3,7,1,58,69,76,89,11};
        for(int i=0;i<arr.length;i++)
        {
        	int min =i;
        	{
        		for (int j=i+1;j<arr.length;j++)
        		{
        			if (arr[j]>arr[min])
        			{
        				min=j;
        			}
        			if (min !=0)
        				temp=0;
        		        temp=arr[min];
        		        arr[min]=arr[i];
        		        arr[i]=temp;
        			}
        		}
        	}
        
       for(int i:arr) 
    	   System.out.println(i);
	}

}
