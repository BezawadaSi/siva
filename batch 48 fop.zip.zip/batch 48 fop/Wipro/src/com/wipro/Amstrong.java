package com.wipro;
import java.util.Scanner;
public class Amstrong {

    public static void main(String[] args) {

        int num , number, temp, total = 0;
         Scanner siva= new Scanner(System.in);
            System.out.println("Enter number ");
            num=siva.nextInt();
             number = num;
     do
        {
           
            temp = number % 10;
            total = total + temp*temp*temp;
            number /= 10;
            
        }while (number != 0);

        if(total == num)
            System.out.println(num + " is an Armstrong number");
            else
            System.out.println(num + " is not an Armstrong number");
    }

}
