package com.wipro;
import java.util.Scanner;
public class Palindrome {
	 public static void main(String args[]){  
		  int r,sum=0,temp,n;    
		  Scanner siva= new Scanner(System.in);
		  System.out.println("Enter number ");
		  n=siva.nextInt();
		  temp= n;
		do {    
		   r=n%10;
		   sum=(sum*10)+r;    
		   n=n/10;    
		  }   while(n>0);
		  
		  if(temp==sum)    
		   System.out.println("palindrome number ");    
		  else    
		   System.out.println("not palindrome");    
		}  
		} 
