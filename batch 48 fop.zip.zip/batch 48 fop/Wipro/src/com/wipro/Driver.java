package com.wipro;

public class Driver {
	public static void main(String[] args) {
		Interface1 i1 = new Class1();
		i1.printMsg();
		i1 = new Class2();
		i1.printMsg();
		
		Class3 c3= new Class3();
		c3.printMsg();
		Interface1 i11=new Class3();
		i11.printMsg();

		Interface2 i2=new Class3();
		i2.printMsg();
	}

}
