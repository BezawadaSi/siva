/*package com.wipro;

public class EmployyeeDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1= new Employee();
		Employee e2=new Employee("siva",123,4500);
		System.out.println(e1);
		System.out.println(e2);
        e1.setEmpName("krishna");
        e1.setEmpId(124);
        e1.setEmpSal(45000);
        e1.setCompany("infosys");
        System.out.println(e1);
        Employee e3=new Employee("naveen",768,98989);
        //System.out.println(e3);
        Employee e4 = new Employee("Sudeepthi",456,65000, "Tcs");
        Employee e5=new Employee("Srinu",222);
        Employee e6=new Employee("sai",333);
        System.out.println(e3);
        System.out.println(e4);
        System.out.println(e5);
        System.out.println(e6);
}
}*/
package com.wipro;
 
public class EmployyeeDriver {
 
	public static void main(String[] args) {
		
		Employee e1=new Employee();//default constructor
		Employee e2=new Employee("Swapna",123, 50000);//with parameters
		System.out.println(e1);
		System.out.println(e2);
		e1.setEmpName("Amit");
		e1.setEmpId(567);
		e1.setEmpSal(80000);
		e1.setCompany("Infosys");
		System.out.println(e1);
		
		Employee e3=new Employee("Siva",789,70000);
		System.out.println(e3);
		Employee e4=new Employee("Anutha",456,60000,"CTS");
		
		Employee e5=new Employee("Gayatri",222);
		Employee e6=new Employee("Akshitha",333);
		
		
		System.out.println(e4);
		System.out.println(e5);
		System.out.println(e6);
 
	}
 
}