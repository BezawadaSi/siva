package com.wipro;

public class Customer1 implements Comparable<Customer1>  {

	private int custid;
	private String name;
	private String city;
	private String state;
	public Customer1() {
		super();
	}
	public Customer1(int custid, String name, String city, String state) {
		super();
		this.custid = custid;
		this.name = name;
		this.city = city;
		this.state = state;
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Customer1 [custid=" + custid + ", name=" + name + ", city=" + city + ", state=" + state + "]";
	}
	//@Override
	/*public int compareTo(Customer1 o)
	{
		//return o.custid-this.custid;
		return  this.custid-o.custid;
	}*/
	//@Override
	/*public int compareTo(Customer1 o) {
		return this.name.compareTo(o.name);
	}*/
	@Override
	public int compareTo(Customer1 o) {
		return this.city.compareTo(o.city);
	}
	
}
