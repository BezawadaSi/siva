package com.wipro;
import java.util.Comparator;
public class cityComparator implements Comparator<Customer1> {
	@Override
	public int compare(Customer1 o1,Customer1 o2) {
		return o1.getCity().compareTo(o2.getCity());
		
	}

}
