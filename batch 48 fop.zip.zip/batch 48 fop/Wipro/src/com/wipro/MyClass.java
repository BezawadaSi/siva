package com.wipro;

public class MyClass {
	public static class Parent{
		public static void sayHello() {
			System.out.println("hello from parent");
		}
	}
	public static class Child1 extends Parent
	
	{
		public static void sayHello()
		{
		System.out.println("hello from child1");
	}

}
    public static class Child2 extends Parent
    {
    	public static void sayHello() {
   
	 System.out.println("hello from child2");
 }
    }
    public static void main(String args[])
    {
    	Parent p = new Parent();
    	p.sayHello();
    	Child1 ch1=new Child1();
    	ch1.sayHello();
    	p=ch1;
    	p.sayHello();
    }
}
