package com.wipro;

public interface Interface2 {

	public default void  printMsg() {
		System.out.println("from msg");
	}
}
