package com.wipro;

public interface ScientificCalculaterInterface {

	public double Power(double a,double b);
	public double sqareRoot(double a );
	
}
