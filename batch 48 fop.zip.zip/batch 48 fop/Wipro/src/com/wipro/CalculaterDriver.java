package com.wipro;

public class CalculaterDriver {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

		
		Calculaterinterface ci=new Calculater1();
		Calculater1 cal=new Calculater1();
		System.out.println(ci.add(5,6));
		System.out.println(ci.mul(5,6));
		
		System.out.println(cal.Power(5, 6));
	    ScientificCalculaterInterface sci = new Calculater1();
	    System.out.println(sci.sqareRoot(144));
		
	    System.out.println(ci.findModulo(66, 10));
	    //Calculaterinterface.display();
	}

}
