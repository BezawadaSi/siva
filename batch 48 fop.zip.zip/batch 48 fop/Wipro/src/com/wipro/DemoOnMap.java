package com.wipro;

import java.util.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DemoOnMap {
 public static void main(String[] args) {
	Map<Integer , String> map=new HashMap<Integer , String>();
	map.put(23, "siva");
	map.put(10, "sudeepthi");
	map.put(45,"naveen");
	System.out.println(map);
	System.out.println(map.containsValue("siva"));
	System.out.println(map.containsKey(45));
	
	Set<Integer> keyset=map.keySet();
	//Set<String> valueSet=(Set<String>) map.values();
	Set<Entry<Integer ,String>> entrySet=map.entrySet();
	System.out.println(map.get(10));
	Iterator<Entry<Integer ,String>> itr=entrySet.iterator();
	while(itr.hasNext())
		System.out.println(itr.next());
	//map.put(null, "abc");
	System.out.println(map);
	//map.put(null,"def");
	System.out.println(map);
	//map.put(1, null);
	//map.put(2, null);
	System.out.println(map);
    
	
	
	LinkedHashMap<Integer , Integer > lhm = new LinkedHashMap<Integer,Integer>();
	TreeMap<Integer,String> tm =new TreeMap<Integer,String>();
	tm.put(15, "apple");
	tm.put(12, "ball");
	tm.putAll(map);
	System.out.println(tm);
	
	
}
}
