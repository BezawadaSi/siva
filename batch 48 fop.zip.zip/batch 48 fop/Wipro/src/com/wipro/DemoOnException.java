package com.wipro;

public class DemoOnException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=6,b=0;
		//System.out.println(a/b);
		//System.out.println("Program completed");
		System.out.println("Bezawada Siva krishna");
		try {
			System.out.println(a/b);
		}
	catch (ArrayIndexOutOfBoundsException ae) {
		ae.printStackTrace();
		
	}
	//catch(ArithmeticException ae) {
	//	ae.printStackTrace();
	//}
		//catch(RuntimeException ae) {
			//	ae.printStackTrace();
			//}
		//catch (Exception e)
		//{
			//e.printStackTrace();
		//}
		finally {
			System.out.println("finally Block executed");
		}
System.out.println("Program completed");

}
}
