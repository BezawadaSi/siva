package com.wipro;

public class Class2 implements Interface1 {

	@Override
	public void printMsg() {
		System.out.println("class 2");

	}

}
