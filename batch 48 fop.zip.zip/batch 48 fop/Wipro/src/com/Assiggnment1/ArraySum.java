package com.Assiggnment1;

import java.util.ArrayList;
import java.util.Collections;

public class ArraySum {
	public static ArrayList<Integer> findSum(int[] A, int[] B) {
        int n = A.length;
        int m = B.length;
        int carry = 0;
        ArrayList<Integer> sum = new ArrayList<>();

        // Iterate from the end of the arrays
        for (int i = n - 1, j = m - 1; i >= 0 || j >= 0 || carry > 0; i--, j--) {
            int digitA = (i >= 0) ? A[i] : 0;
            int digitB = (j >= 0) ? B[j] : 0;

            int digitSum = digitA + digitB + carry;
            sum.add(digitSum % 10); // Add the unit digit to the sum array
            carry = digitSum / 10; // Carry over the tens digit for next iteration
        }

        // Reverse the sum array to get the correct order (most significant digit first)
        Collections.reverse(sum);

        // Remove leading zeros (if any)
        while (sum.size() > 1 && sum.get(0) == 0) {
            sum.remove(0);
        }

        return sum;
    }

    public static void main(String[] args) {
    	System.out.println("***********************");
        System.out.println("Bezawada siva krishna");
        System.out.println("************************");
       
        int[] A1 = {1, 2, 3, 4};   //{4, 5, 1}
        int[] B1 = {6};            //{ 3,4,5}
        ArrayList<Integer> sum1 = findSum(A1, B1);
        System.out.println(sum1); // Output: [1, 2, 4, 0]   o/p2 {7 , 9 , 6}

        int[] A2 = {1, 2, 3};           //{ 1 , 1}
        int[] B2 = {9, 9};             //{1,2}
        ArrayList<Integer> sum2 = findSum(A2, B2);
        System.out.println(sum2); // Output: [2, 2, 2]   o/p2 {2 , 3}
    }
}

