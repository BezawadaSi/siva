package com.Assiggnment1;

public class AnagramChecker {
	 static boolean isAnagram(String a, String b) {
	      
	        a = a.toLowerCase();
	        b = b.toLowerCase();

	        
	        if (a.length() != b.length()) {
	            return false;
	        }

	     
	        int[] charCount = new int[26]; 

	       
	        for (char c : a.toCharArray()) {
	            charCount[c - 'a']++;
	        }

	       
	        for (char c : b.toCharArray()) {
	            charCount[c - 'a']--;
	            if (charCount[c - 'a'] < 0) {
	                return false; 
	            }
	        }

	       
	        return true;
	    }

	    public static void main(String[] args) {
	        String str1 = "anagram";
	        String str2 = "margana";
	        System.out.println("***********************");
	        System.out.println("Bezawada siva krishna");
	        System.out.println("************************");
	        
	        if (isAnagram(str1, str2)) {
	            System.out.println("Anagrams");
	        } else {
	            System.out.println("Not Anagrams");
	        }
	    }
	}

