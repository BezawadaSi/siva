package com.Assiggnment1;
import java.util.Scanner;
public class Wired {
	 public static void main(String[] args) {
	        /*Scanner scanner = new Scanner(System.in);
	        System.out.println("***********************");
	        System.out.println("Bezawada siva krishna");
	        System.out.println("************************");
	      

	        int n = scanner.nextInt();
	        scanner.close(); // Close the scanner to avoid resource leaks

	        String result = "";

	        // Check if odd, then it's weird
	        if (n % 2 != 0) {
	            result = "Weird";
	        } else {
	            // Check if even and within the specific ranges
	            if (n >= 2 && n <= 5) {
	                result = "Not Weird";
	            } else if (n >= 6 && n <= 20) {
	                result = "Weird";
	            } else {
	                result = "Not Weird";
	            }
	        }

	        System.out.println(result);*/
		// What is the output of the following?
				// public static void main1(String args[])
				  String chair = null, table = "metal";
				 chair = chair + table;
				 System.out.println(chair);
	    }
	}
