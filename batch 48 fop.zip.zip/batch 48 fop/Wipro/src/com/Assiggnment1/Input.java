package com.Assiggnment1;

import java.util.Scanner;

public class Input {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************");
        System.out.println("Bezawada siva krishna");
        System.out.println("************************");
       
		Scanner scanner = new Scanner(System.in); 
        while (scanner.hasNextInt()) {
            int num = scanner.nextInt();
            System.out.println(num); 
        }

        scanner.close(); 

	}

}



