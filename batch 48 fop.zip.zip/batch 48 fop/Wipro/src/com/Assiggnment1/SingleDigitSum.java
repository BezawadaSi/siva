package com.Assiggnment1;

public class SingleDigitSum {
	public static int singleDigitSum(int[] arr) {
		System.out.println("***********************");
        System.out.println("Bezawada siva krishna");
        System.out.println("************************");
       
        int sum = 0;

        // Calculate the initial sum of all elements
        for (int num : arr) {
            sum += num;
        }

        // Keep adding digits of the sum until it becomes single digit
        while (sum > 9) {
            int newSum = 0;
            while (sum > 0) {
                newSum += sum % 10;
                sum /= 10;
            }
            sum = newSum;
        }

        return sum;
    }

    public static void main(String[] args) {
        int[] arr1 = {8, 7, 0, 1, 2};
        int[] arr2 = {4, 2, 1, 1};

        System.out.println(singleDigitSum(arr1)); // Output: 9
        System.out.println(singleDigitSum(arr2)); // Output: 8
    }
}

