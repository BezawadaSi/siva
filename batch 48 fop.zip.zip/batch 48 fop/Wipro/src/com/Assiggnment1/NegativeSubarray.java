package com.Assiggnment1;
import java.util.Scanner;
public class NegativeSubarray {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("***********************");
        System.out.println("Bezawada Siva krishna");
        System.out.println("***********************");
        System.out.println("enter array Size");
        int n = scanner.nextInt(); 
        int[] arr = new int[n];

        System.out.println("enter array elements");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }
        scanner.close();

        // Count negative subarrays
        int count = 0;
        for (int i = 0; i < n; i++) {
            int currentSum = 0;
            for (int j = i; j < n; j++) {
                currentSum += arr[j];
                if (currentSum < 0) {
                    count++;
                }
            }
        }

        // Print the number of negative subarrays
        System.out.println(count);
    }

}
