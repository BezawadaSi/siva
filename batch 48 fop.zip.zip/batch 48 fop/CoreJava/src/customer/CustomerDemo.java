package customer;
import java.util.Scanner;

public class CustomerDemo {


	public static void main(String[] args) {
		
		Bank bank = new Bank();
		Scanner sc = new Scanner(System.in);
		int choice,amt ,withmoney;
		 //Customer customer=new Customer("siva","krishna","hyd",1200);
	             
	          
		do{
			System.out.println("1.Add  Customer ");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Show customers");
			System.out.println("5.show id ");
			System.out.println("6.Transfer the money");
			System.out.println("7.Exit");
			System.out.println(" Enter your option");
			choice=sc.nextInt();
			//Customer customer=new Customer();       //
			switch(choice){
			case 1 :System.out.println("Enter your Firstname :");
			String fname = sc.next();
			System.out.println("Enter your lastname :");
			String lastname = sc.next();
			System.out.println("Enter your adress :");
			String address = sc.next();
			System.out.println("Enter your balance :");
			double balance = sc.nextDouble();
			
			//String result =bank.addCustomer(fname, lastname, address, balance);
			//System.out.println(result);
			
			break;
			case 2 :{
				System.out.println("enter id");
				int id=sc.nextInt();
				
				System.out.println("enter money you want to deposit");
				amt=sc.nextInt();
			
				//bank.deposit(id,amt);
				String result1=bank.deposit(id, amt);
				System.out.println(result1);
			
		
				break;
				
			}
			case 3:
			{ System.out.println("enter id");
			int id=sc.nextInt();
				System.out.println("enter money you want to withdraw");
				withmoney=sc.nextInt();
				bank.withDraw(id,withmoney);
				break;
			}
			case 4:
				bank.showCustomer();
				break;
			case 5:
				System.out.println("Enter your Id :");
				int Id =sc.nextInt();
				Customer result5 =bank.printWithId(Id);
				result5.showDetails();
				break;
			case 6:
				System.out.println("Enter Id1 :");
				int Id1 =sc.nextInt();
				System.out.println("Enter Id2 :");
				int Id2 = sc.nextInt();
				System.out.println("Enter amount :");
				double amount=sc.nextDouble();
				String resultTransfer = bank.transfer(Id1, Id2, amount);
				System.out.println(resultTransfer);
				
			case 7:
			{
				System.exit(0);
				break;
			}
			
			
			}
			
			
			
		}while(choice<6);
		
		
		
	
	}

}