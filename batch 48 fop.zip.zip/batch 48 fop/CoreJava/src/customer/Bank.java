package customer;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class Bank {
	
	
	
	//Customer[] customerList = new Customer[30];
	//static int index=0;
	
	//Customer sis=new Customer(String firstNam,String lastName,String address,double balance);
	
	
	
	/*public 	String addCustomer(String firstNam,String lastName,String address,double balance){
		
		
		Customer customer = new Customer(firstNam,lastName,address,balance);
		customerList[index++]=customer;
		
		return "Account created Successfully " + customer.getId();
		
	}*/
	List<Customer> cus=new ArrayList<Customer>();
public 	String addPersonalCustomer(String firstNam,String lastName,String address,double balance,String homephone,String workphone){
		PersonalCustomer pcustomer = new PersonalCustomer(firstNam,lastName,address,balance,homephone,workphone);
		cus.add(pcustomer);
		return "Account created Successfully " + pcustomer.getId();
	}
	
	public 	String addcommercialCustomer(String firstNam,String lastName,String address,double balance,String contactphone,String businessphone){
		CommercialCustomer Ccustomer = new CommercialCustomer(firstNam,lastName,address,balance,contactphone,businessphone);
	cus.add(Ccustomer);
		return "Account created Successfully " + Ccustomer.getId();
	}


public String deposit(int id ,double amount){
		for(int i=0;i<cus.size();i++){
			if(cus.get(i).getId()==id){
				cus.get(i).setBalance(cus.get(i).getBalance()+amount);
				
				return "Amount added successfully"+ cus.get(i).getBalance();
			}
		}
		
		return " Customer not fount";
		
	}
public String withDraw(int id, double withmoney){
	
	for(int i =0;i<cus.size();i++){
		if(cus.get(i).getId()==id);
		cus.get(i).setBalance(cus.get(i).getBalance()-withmoney);
		return cus.get(i).getFirstName()+" "+"Amount withdrawed successfully "+cus.get(i).getBalance();
	}
	
	return "Id not found..";
	
}
public String transfer(int id1,int id2,double amount){

	for (int i = 0;i<cus.size();i++){
		boolean check=false;
		if(id1==cus.get(i).getId()){
			if(cus.get(i).getBalance()>=amount){
				check = true;
				cus.get(i).setBalance(cus.get(i).getBalance()-amount);
				System.out.println("Transfer successfully done.."+cus.get(i).getFirstName()+" your current balance is :"+cus.get(i).getBalance());
			}
			else{
				System.out.println("Insuffient funds..");
			}
		}
		if(id2==cus.get(i).getId()){
			cus.get(i).setBalance(cus.get(i).getBalance()+amount);
			System.out.println("Transfer successfully done.."+cus.get(i).getFirstName()+" your current balance is :"+cus.get(i).getBalance());
		}
		
			
			
		}
	



	return null;

}
public void showCustomer() {
	
	for (int i = 0; i < cus.size(); i++) {
		System.out.println(cus.get(i));
	}	}
public Customer printWithId(int Id ){
	
	for (int i=0;i<cus.size();i++){
		if(Id == cus.get(i).getId()){
			return (cus.get(i));
		}
		
	}
	return null;
	
}
public void saveCustomerData(String file){
	FileOutputStream fos = null;
	ObjectOutputStream oos = null;
	try {
		fos = new FileOutputStream("D:/corejava/"+file+".txt");
		try{
			oos = new ObjectOutputStream(fos);
			java.util.List<String> lines=new ArrayList<String>();  
			for (int i =0;i<cus.size();i++){
				String line = cus.get(i).getId()+","+cus.get(i).getFullname()+","+cus.get(i).getAdress()+","+cus.get(i).getBalance();
				lines.add(line);
				try {
					oos.writeObject(lines);
					System.out.println("success.");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}catch(IOException e) {
			e.printStackTrace();
		}
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}
	finally{
		try {
			oos.close();
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
	

}
