package customer;

class CommercialCustomer extends Customer{
	
	private String contactPhone;
	private String  businessphone;
	public CommercialCustomer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CommercialCustomer(String firstName, String lastName, String adress, double balance,String contactPhone, String businessphone) {
		super(firstName, lastName,  adress, balance);
		this.contactPhone = contactPhone;
		this.businessphone = businessphone;
	}
	public String getContactPhone() {
		return contactPhone;
	}
	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}
	public String getBusinessphone() {
		return businessphone;
	}
	public void setBusinessphone(String businessphone) {
		this.businessphone = businessphone;
	}
	public double interst()
	{
		return (balance*5)/100;
	}
	public void showDetails(){
		System.out.println("Id: "+id);
		System.out.println("Name: "+getFullname());
		System.out.println("Address: "+Adress);
		System.out.println("Balance: "+balance);
		System.out.println("Homephone: "+contactPhone);
		System.out.println("Workphone: "+businessphone);
		System.out.println("Interest: "+interst());
	}
	/*@Override
	public String toString() {
		return "CommercialCustomer [contactPhone=" + contactPhone + ", businessphone=" + businessphone + ", id=" + id
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", Adress=" + Adress + ", balance=" + balance
				+ "]";
	}*/
	
	
	

}

