package customer;

public class PersonalCustomer  extends Customer{
	
	private String homePhone;
	private String workphone;
	public PersonalCustomer() {
		super();
	}
	public PersonalCustomer(String firstName, String lastName, String adress, double balance,String homePhone, String workphone) {
		super(firstName, lastName, adress, balance);
		this.homePhone = homePhone;
		this.workphone = workphone;
	}
	public String getHomePhone() {

		return homePhone;
	}
	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}
	public String getWorkphone() {
		return workphone;
	}
	public void setWorkphone(String workphone) {
		this.workphone = workphone;
	}
	public double interst()
	{
		return (balance*4)/100;
	}
	public void showDetails(){
		System.out.println("Id: "+id);
		System.out.println("Name: "+getFullname());
		System.out.println("Address: "+Adress);
		System.out.println("Balance: "+balance);
		System.out.println("Homephone: "+homePhone);
		System.out.println("Workphone: "+workphone);
		System.out.println("Interest: "+interst());
	}
	/*@Override
	public String toString() {
		return "PersonalCustomer [homePhone=" + homePhone + ", workphone=" + workphone + ", id=" + id + ", firstName="
				+ firstName + ", lastName=" + lastName + ", Adress=" + Adress + ", balance=" + balance + "]";
	}*/
	

	
	
	
	

}