package customer;

abstract public class Customer {
	protected int id;
	protected String firstName;
	protected String lastName;
	protected String Adress;
	protected double balance;
	private static int counter=1000;
	public Customer() {
		this.id=counter++;
		
	}
	public Customer( String firstName, String lastName, String adress, double balance) {
		//super();
		this.id = counter++;
		this.firstName = firstName;
		this.lastName = lastName;
		Adress = adress;
		this.balance = balance;
	}
	
	
	
	
	public int getId() {
		return id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAdress() {
		return Adress;
	}
	public void setAdress(String adress) {
		Adress = adress;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public abstract double interst();
	 public abstract void showDetails();
	 public String getFullname()
	 {
		 return firstName+lastName;
	 }
	
	/*@Override
	public String toString() {
		return "Customer [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", Adress=" + Adress
				+ ", balance=" + balance + "]";
	}*/
}

