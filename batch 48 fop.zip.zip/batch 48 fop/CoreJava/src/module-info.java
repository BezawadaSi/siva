/**
 * 
 */
/**
 * @author SIVA
 *
 */
module CoreJava {
	requires java.desktop;
}