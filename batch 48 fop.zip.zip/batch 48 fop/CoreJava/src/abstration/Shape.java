package abstration;

abstract class Shape {
    public abstract double getArea();
    public abstract void printDetails();
}

class Rectangle extends Shape {
    private double length;
    private double breadth;
    public Rectangle(double length, double breadth)
    {
        this.length = length;
        this.breadth = breadth;
    }
    public double getArea() {
        return length * breadth;
    }
    public void printDetails() {
        System.out.println("Type = Rectangle");
        System.out.println("Length = " + length);
        System.out.println("Breadth = " + breadth);
        System.out.println("Area = " + getArea());
    }
}
class Circle extends Shape {
    private double radius;
    public Circle(double radius) {
        this.radius = radius;
    }
    public double getArea() {
        return Math.PI * radius * radius;
    }
    public void printDetails() {
        System.out.println("Type = Circle");
        System.out.println("Radius = " + radius);
        System.out.println("Area = " + getArea());
    }
}
class Triangle extends Shape {
    private double base;
    private double height;
    public Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }
    public double getArea() {
        return 0.5 * base * height;
    }
    public void printDetails() {
        System.out.println("Type = Triangle");
        System.out.println("Base = " + base);
        System.out.println("Height = " + height);
        System.out.println("Area = " + getArea());
    }
}

