package abstration;

abstract class Animal
{
    abstract void display();
}

class dog extends Animal
{
    void display()
    {
        System.out.println("bow bow");
    }
    
}

class cat extends Animal
{
    void display()
    {
        System.out.println("meow meow ");
    }
    
}
class lion extends Animal
{
	void display()
	{
		System.out.println("lion is roaring ");
	}
}
