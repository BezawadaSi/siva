package abstration;

public class Test{
	public static void main(String[] args) {
	Shape siva=new Rectangle(12.12,13.25);
	siva.printDetails();                       //System.out.println(siva.printDetails());
    System.out.println();
	Shape siva1=new Circle(5.25);
	siva1.printDetails();                 //System.out.println(siva1.printDetails());
	System.out.println();
	Shape siva2=new Triangle(4.25,15.23);
	siva2.printDetails();
	
	}
	}