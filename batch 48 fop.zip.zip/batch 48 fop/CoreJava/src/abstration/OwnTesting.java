package abstration;

class AbstractMethodExample 
{
    public static void main(String arg[])
    {
        Animal add = new cat();
        add.display();
        
        Animal sub = new dog();
      sub.display();
      Animal s=new lion();
      s.display();
}
}