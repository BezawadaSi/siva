package day_02;

public class TalentSprint_testing {

	public static void main(String[] args) {
	TalentSprint sample = new TalentSprint(7.50,35);
	sample.computeSalary();
	System.out.println(sample);
	TalentSprint sample1 = new TalentSprint(8.20,47);
	sample1.computeSalary();
	System.out.println(sample1);
	TalentSprint sample2 = new TalentSprint(10.00,3);
	sample2.computeSalary();
	System.out.println(sample2);
	}

}
