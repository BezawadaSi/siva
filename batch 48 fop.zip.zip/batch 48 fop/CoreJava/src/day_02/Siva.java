package day_02;

public class Siva {

	public static void main(String[] args) {
		int a =1000;
		int zeros=0;
		for(int i=5;i<=a;i+=5)
		{
			int temp=i;
			while(temp%5==0)
			{
				zeros++;
				temp/=5;
			}
		}
		System.out.println(zeros);
	}

}
