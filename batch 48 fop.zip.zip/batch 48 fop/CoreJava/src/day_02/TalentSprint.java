package day_02;

public class TalentSprint {
private double basePay;
private int hoursWorked;
public TalentSprint(){
	
}
public TalentSprint(double basePay,int hoursWorked){
	this.basePay=basePay;
	this.hoursWorked=hoursWorked;
}
public String computeSalary(){
	String result="";
	if(basePay>=8 && hoursWorked<=60){
		if (hoursWorked>40){
			double hour = 40*basePay;
			int overtime = hoursWorked-40;
			double overtime_salary =  (overtime*1.5);
			result = "The salary is :"+(hour+overtime_salary);
		}
		if(hoursWorked<40){
			result ="The salary is :"+(hoursWorked*basePay);
		}

	}
	else{
		result="error:";
	}
	return result;
}
@Override
public String toString() {
	return "TalentSprint [basePay=" + basePay + ", hoursWorked=" + hoursWorked + ", computeSalary()=" + computeSalary()
			+ "]";
}



}


