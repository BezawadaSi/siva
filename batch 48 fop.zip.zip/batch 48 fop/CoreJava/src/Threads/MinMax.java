package Threads;

import java.util.Arrays;

public class MinMax {

	public static void main(String[] args) {
	int a[]= {54,546,548,60};
	Arrays.sort(a);
	System.out.println("maximum value is :"+a[a.length-1]+"  Min value is :"+a[0] );
	
	
	}

}
