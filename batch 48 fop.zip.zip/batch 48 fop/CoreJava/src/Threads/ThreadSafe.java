package Threads;
class reservation1 extends Thread{
	private int available=10;
	public synchronized void ticketReservation(int want){	
		System.out.println("tickets available "+available );
		String name = Thread.currentThread().getName();	
		if(want<=available){
			System.out.println("ticket alloted to :"+ name);

			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			available-=want;
		}
		else{
			System.out.println("sorryyy...!!! tickets not available");
		}
	}	
}
public class ThreadSafe {

	public static void main(String[] args) {


		reservation1 reservation = new reservation1();


		Thread t = new Thread(){

			public void run(){
				reservation.ticketReservation(1);

			}
		};

		Thread t1 = new Thread(){

			public void run(){
				reservation.ticketReservation(5);

			}
		};

		Thread t2= new Thread(){

			public void run(){

				reservation.ticketReservation(1);

			}
		};
		Thread t3= new Thread(){

			public void run(){

				reservation.ticketReservation(2);

			}
		};
		t.start();
		t1.start();
		t2.start();
		t3.start();
	}

}