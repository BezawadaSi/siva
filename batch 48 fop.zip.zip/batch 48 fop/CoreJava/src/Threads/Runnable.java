package Threads;
class car {
	private String brand;
	public car() {
		super();
	}
	public car(String brand) {
		super();
		this.brand = brand;
	}
	public void display1(){
		System.out.println("Car: "+brand);
		System.out.println(Thread.currentThread());
	}
}
class benzCar extends car implements Runnable{
	private int no_of_wheel;
	@Override
	public void run() {
		System.out.println("Runnable");
	}
	public benzCar() {
		super();
		// TODO Auto-generated constructor stub
	}
	public benzCar(int no_of_wheel,String brand) {
		super(brand);
		this.no_of_wheel = no_of_wheel;
	}
	public void display(){
		System.out.println("no of wheels: "+no_of_wheel);
		System.out.println(Thread.currentThread());
	}
}

 class Assignment_Runnable {

	public static void main(String[] args) {
		benzCar benz = new benzCar(4,"BMW");
		Thread t = new Thread(benz);
		t.start();
		benz.display();
		benz.display1();
		System.out.println(t.getName());
		//System.out.println(t.getId());
		System.out.println(Thread.currentThread());
		System.out.println(t.getPriority());
		System.out.println(t.isAlive());
		System.out.println(t.isDaemon());
		t.setName("shiva");
		System.out.println(t.toString());
		System.out.println();
	}

}