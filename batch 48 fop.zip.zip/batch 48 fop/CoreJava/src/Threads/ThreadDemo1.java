package Threads;
	class MyThread  implements Runnable{
		public void run(){
			System.out.println("child thread is started");
			for(int i=1;i<=10;i++){
				System.out.println(i);
			}
			System.out.println("child thread is ended");
		}
		
	}
	public class ThreadDemo1 {
		public static void main(String[] args) {
			System.out.println("main thread is started");
			System.out.println("Current thread "+Thread.currentThread());
			
			MyThread mythread = new MyThread();
			Thread t = new Thread( );
			t.start();
			
			System.out.println("main thread is ended");
		}

	}


