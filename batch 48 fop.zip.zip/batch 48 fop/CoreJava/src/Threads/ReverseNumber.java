package Threads;

public class ReverseNumber {

	public static void main(String[] args) {
		int a=100;
		int rem=0,rev=0;
	
		while(a!=0) {
			rem=a%10;
			if(rem!=0||rev!=0) {
			rev=(rev*10)+rem;
			}
			a=a/10;
			
		}
	System.out.println(rev);
		

	}

}
