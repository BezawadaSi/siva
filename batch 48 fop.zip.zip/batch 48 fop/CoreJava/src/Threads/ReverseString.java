package Threads;

public class ReverseString {

	public static void main(String[] args) {
		String s="codecode";
		char c[]=s.toCharArray();
		for(int i=c.length-1;i>=0;i--) {
			System.out.print(c[i]);
		}

	}

}
