package inheritance;
class Parent{
	protected int a,b;
	public Parent(){
		//super();
		System.out.println("Im parent constructor");
	}
	public Parent(int a, int b) {
		//super();
		this.a = a;
		this.b = b;
	}
	public void parentshow(){
		System.out.println("this is parent ,method");
	}
}
class Child extends Parent{
	private int c;
	
	public Child(){
		//super();
		System.out.println("Im child constructor");
	}
	public Child(int a,int b, int c) {
		super(a,b);
		this.c = c;
	}
	public void childshow(){
		System.out.println("this is child ,method");
	}
	
	public void display(){
		System.out.println("the sum is:" + (a+b+c));
	}
}
public class InheritanceTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
Child child = new Child(20,50,100);
child.parentshow();
child.childshow();
child.display();



	}

}

	