package day_01;

public class Emp_Tester {

	public static void main(String[] args) {
		Employee siva=new Employee("siva","krishna",121,1000);
	 
		siva.display();

	}

}
