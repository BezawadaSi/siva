package day_01;

class Job{
	private int jobId,salary;private String f_name,l_name; private static int count=100;
public Job(int jobId,String f_name,String l_name,int salary)
{
	this.jobId=jobId;
	this.f_name=f_name;
	this.l_name=l_name;
	this.salary=salary;
	this.jobId=++count;
}
	public void display()
	{
		System.out.println("job id :="+jobId);
		System.out.println("first name :="+f_name);
		System.out.println("last name :="+l_name);
		System.out.println("salary :="+salary);
	}
}