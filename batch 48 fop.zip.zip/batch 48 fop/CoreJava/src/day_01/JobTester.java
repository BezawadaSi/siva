package day_01;

public class JobTester {

	public static void main(String[] args) {
		Job siva=new Job( 1,"siva","krishna",10000);
		siva.display();
		Job siva1=new Job( 2,"pavan","kumar",12000);
		siva1.display();
		Job siva2=new Job( 3,"sai","krishna",40567);
		siva2.display();
		Job siva3=new Job( 4,"naveen","krishna",67890);
		siva3.display();
		Job siva4=new Job( 5,"dusanth","sai",12345);
		siva4.display();
		Job siva5=new Job( 6,"suvidh","sai",11389);
		siva5.display();

	}

}
