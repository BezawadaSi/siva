package day_01;

public class Sample1Tester {

	public static void main(String[] args) {
		Sample1 siva=new Sample1("Siva","doctor",8886.78,54);
	
		System.out.println(siva);
		siva.setSalary(209474);
		
		System.out.println(siva.getSalary());
		System.out.println(siva);
	}

}
