package day_01;

import java.lang.Math;
/*class Solution {
 public int solution(int[] A){
int N = A.length;
if (N < 2) {
return -1; // Invalid input array
}int maxSum = Integer.MIN_VALUE;
for (int i = 0; i < N - 1; i++) {
if (i + 1 < N) {
int tile1Sum = A[i] + A[i + 1];
for (int j = i + 2; j < N - 1; j++) {
if (j + 1 < N && j + 1 != i && j + 1 != i + 1) {
int tile2Sum = A[j] + A[j + 1];
for (int k = j + 2; k < N - 1; k++) {
if (k + 1 < N && k + 1 != i && k + 1 != i + 1 && k + 1 != j && k + 1 != j + 1) {
int tile3Sum = A[k] + A[k + 1];
int currentSum = tile1Sum + tile2Sum + tile3Sum;
maxSum = Math.max(maxSum, currentSum);

}
}
}
}
}
}
if (maxSum == Integer.MIN_VALUE) {
return -1; // No valid tile positions found
}
return maxSum;
}
}*/
class Siva
{
	public static void main(String[] args) {
		String a="Striing";
		String b=new String("String");
		String c=a;
		System.out.println(a==b);
		System.out.println(a==c);
		System.out.println(b.equals(c));
	}
}