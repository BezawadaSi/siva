package day_01;

public class Sample1 {
	private String EmployeeName;
	private  String  Jobrole;
	private  double  Salary;
	private   int Age;
	
	
	
	public Sample1(String EmployeeName, String jobrole, double Salary, int Age) {
		this.EmployeeName=EmployeeName;
		this.Jobrole=jobrole;
		this.Salary=Salary;
		this.Age=Age;
	}
	public  String getName(){
		return EmployeeName;
	}
	public void setName(String EmployeeName){
		this.EmployeeName=EmployeeName;
	}
	public  String getjobrole(){
		return Jobrole;
	}
	public void setjobrole(String jobrole){
		this.Jobrole=jobrole;
	}
	public  double getSalary(){
		return Salary;
	}
	public void setSalary(double Salary){
		this.Salary=Salary;
	}
	public  int getAge(){
		return Age;	
	}
	
	public String toString() {
		return "Sample1 [EmployeeName=" + EmployeeName + ", Jobrole=" + Jobrole + ", Salary=" + Salary + ", Age=" + Age
				+ "]";
	}
	
	
	
	
}
