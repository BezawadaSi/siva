
package day_01;

 class Sample {
	 private int a,b;
	 public void storing(int a,int b)
	 {
		 this.a=a;
		 this.b=b;
	 }
    public void display()
    {
    	System.out.println(a);
    	System.err.println(b);
    }
    public void addition()
    {
    	System.out.println("the sum of two numbers is :"+(a+b));
    	
    }

}
