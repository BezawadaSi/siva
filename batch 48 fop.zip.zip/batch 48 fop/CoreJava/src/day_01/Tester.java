package day_01;

public class Tester {

	public static void main(String[] args) {
	Sample siva=new Sample();
	siva.storing(10,20);
	siva.display();
	siva.addition();
	
		

	}

}
