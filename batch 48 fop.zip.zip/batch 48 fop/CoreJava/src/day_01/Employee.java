package day_01;

class Employee {
	private String f_name,l_name;int emp_id ,salary;
	
	public  Employee(String f_name,String l_name,int emp_id, int salary)
	{
		this.f_name=f_name;
		this.l_name=l_name;
		this.salary=salary;
		this.emp_id=emp_id;
	}
	public void display()
	{
		System.out.print(f_name+" ");
		System.out.print(l_name+" ");
		System.out.print(emp_id+" ");
		System.out.println(salary+" ");
	}
	
}	