package collections;

import java.util.Comparator;

public class SortByName implements Comparator<Employee>{

	
	public int  compare(Employee name, Employee name1) {
		return name.getName().compareTo( name1.getName());
	}

}