package collections;

import java.util.*;
public class ArrayList1 {

	public static void main(String[] args) {
   ArrayList<String> al=new ArrayList<>();
		al.add("si");
		al.add("be");
		LinkedList<String> ll=new LinkedList<>();
		ll.add("siva");
		ll.add("krishna");
		ll.add("vamsi");
		ll.add("nandu");
		ll.add("pavan");
		ll.addAll(4,al);
		ll.remove(2);
		ll.add(2,"naveen");
		ll.add(6,"sai krishna bezawada");
		
		//ll.removeAll(ll);
		ll.addFirst("402");
		ll.addLast("345");
		System.out.println(ll);
		//Iterator it=ll.iterator();
		ListIterator li= ll.listIterator();
		while(li.hasNext())
		{
			System.out.println(li.next());
		}
		System.out.println("==============================");
		/*for(int i=ll.size()-1;i>0;i--)
		{
			System.out.println(ll.get(i));
		}*/
		
		while(li.hasPrevious())
		{
			System.out.println(li.previous());
		}
		
	}

}