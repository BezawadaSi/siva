package collections;

import java.util.Comparator;

public class SortById implements Comparator <Employee> {

	@Override
	public int compare(Employee sal1, Employee sal2) {
		if(sal1.getSalary()>sal2.getSalary())
		{
			return 1;
		}
		else if(sal1.getSalary()<sal2.getSalary())
		{
			return-1;
		}
		else 
	
		return 0;
	

}
}