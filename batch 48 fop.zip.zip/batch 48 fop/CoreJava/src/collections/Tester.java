package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Tester {
	
	public static void main(String[] args) {
		
	
	List <Employee> list=new ArrayList<Employee>();
   Employee emp=new Employee(101,"siva",25000.765);
  list.add(emp);
  Employee emp1=new Employee (105,"krishna",1145.25);
  list.add(emp1);
   Employee emp2=new Employee(100,"sai",2558894.235);
 list.add(emp2);
 Employee emp3 =new Employee (102,"naveen",25412.325);
 list.add(emp3);
 Employee emp4 = new Employee(99,"ramesh",875855.256);
 list.add(emp4);
  System.out.println(list);
 
  Collections.sort(list);
  for (Employee obj:list)
  {
	  System.out.println(obj);
  }
//System.out.println(list);
  System.out.println("==============================================");
  Collections.sort(list,new SortById());
  for (Employee obj:list)
  {
	  System.out.println(obj);
  }
 
  //System.out.println(list);
  System.out.println("================================================");
 
  Collections.sort(list,new SortByName());
  for (Employee obj:list)
  {
	  System.out.println(obj);
  }
 
}
}