package exception;

import customer.Customer;

public class AccountList extends Account {
   Account[] account = new Account[30];
	static int index=0;
public 	String addCustomer(int accountNumber,int balance){
		
		
		Account customer = new Account(accountNumber,balance);
		account[index++]=customer;
		
		return "Account created Successfully " + customer.getAccountNumber();

}
}
