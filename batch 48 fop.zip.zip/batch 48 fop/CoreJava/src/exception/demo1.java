package exception;

public class demo1 {

	public static void main(String[] args) {
		int a=10;
		int b=0;
		try 
		{
		int c=a/b;
		
	}
		catch(Exception siva)
		{
		//siva.printStackTrace();
		System.out.println(siva.toString());
		}
     finally 
{
	System.out.println("program completed ");
}
}
	}
