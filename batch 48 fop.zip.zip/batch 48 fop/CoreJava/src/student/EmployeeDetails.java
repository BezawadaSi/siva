package student;
public class EmployeeDetails {
	public static void main(String[] args) {
		PartTimeEmployee display1 = new PartTimeEmployee("Siva","bezawada","hyd",120,28.0);
		//String result1 = display1.getDetails();
		System.out.println(display1.getDetails());
		FullTimeEmployee display = new FullTimeEmployee("Siva","bezawada","hyd",12000,400.0);
		//String  result = display.showDetails();
		System.out.println(display.showDetails());
		
	}
}
