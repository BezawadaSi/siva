package student;
public class Employee {
	protected int id;
	protected String first_Name;
	protected String last_Name;
	protected String address;
	protected static int count;
	public Employee() {
		
	}
	public Employee(String first_Name, String last_Name, String address) {
		super();
		this.id = count++;
		this.first_Name = first_Name;
		this.last_Name = last_Name;
		this.address = address;
	}
	public String get_fullName(){
		return last_Name+" "+first_Name;
	}
	
	
}