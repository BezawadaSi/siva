package student;

public class FullTimeEmployee extends Employee{
	protected int basic;
	protected double bonus;
	public FullTimeEmployee() {
		
	}
	public FullTimeEmployee(String first_Name, String last_Name, String address, int basic, double bonus) {
		super(first_Name, last_Name, address);
		this.basic = basic;
		this.bonus = bonus;
	}
	public double computeSal(){
		return basic+bonus;
	}
	public String showDetails(){
		String result = "FullTimeEmployee"+ " Id :"+id+ " Full name :"+get_fullName()+" Salary :"+computeSal();
		return result;
	}
	
}


