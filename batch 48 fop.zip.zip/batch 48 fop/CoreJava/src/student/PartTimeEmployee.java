package student;

public class PartTimeEmployee extends Employee{
	protected int hoursWorked;
	protected double amountPerHour;
	public PartTimeEmployee() {
	
	}
	public PartTimeEmployee(String first_Name, String last_Name, String address, int hoursWorked,
			double amountPerHour) {
		super(first_Name, last_Name, address);
		this.hoursWorked = hoursWorked;
		this.amountPerHour = amountPerHour;
	}
	public	double computeSal(){
		return hoursWorked*amountPerHour;
		
	}
	public String getDetails(){
		String result = "PartTimeEmployee"+" Id :"+id+" Full name :"+get_fullName() + " Salary :"+computeSal();
		return result;
	
	}
}


