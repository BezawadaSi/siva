package interfaces;

public class Main {

	public static void main(String[] args) {
		MyCalculator siva= new MyCalculator();
		System.out.println(siva.divisorSum(6));
	}

}
