package interfaces;

public class Apple implements laptop_1{

	@Override
	public void diaply() {
		// TODO Auto-generated method stub
		System.out.println("diaply code");
	}

	@Override
	public void fingerprint() {
		// TODO Auto-generated method stub
		System.out.println("fingerprint code ");
	}

	@Override
	public void battery() {
		// TODO Auto-generated method stub
		System.out.println("battery ");
	}

	@Override
	public void ram() {
		// TODO Auto-generated method stub
		System.out.println("ram code");
	}
	public void ios()
	{
		System.out.println("ios");
	}

}
