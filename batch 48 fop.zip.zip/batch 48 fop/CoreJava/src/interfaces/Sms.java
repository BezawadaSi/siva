package interfaces;

public class Sms implements Message{

	@Override
	public void reveceived() {
		System.out.println("sms received");
		
	}

	@Override
	public void sent() {
		System.out.println("sms sent ");
		
	}

}
