package interfaces;

public class User {

	public static void main(String[] args) {
		Lenovo lenovo=new Lenovo();
		lenovo.diaply();
		lenovo.battery();
		lenovo.fingerprint();
        lenovo.ram();
        lenovo.hdd();
        System.out.println();
        System.out.println("Beazawada. Sivakrishna Chowdary");
        System.out.println();
        Apple apple=new Apple();
        apple.diaply();
        apple.battery();
        apple.fingerprint();
        apple.ios();
        apple.ram();
	}

}
