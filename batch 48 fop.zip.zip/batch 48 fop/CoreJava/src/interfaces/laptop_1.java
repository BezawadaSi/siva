package interfaces;

public interface laptop_1 {
	abstract void diaply();
	abstract void fingerprint();
	void battery();
	public void ram();
	
}
