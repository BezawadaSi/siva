package interfaces;

public interface Message {
	 void reveceived();
	void sent();
	

}
