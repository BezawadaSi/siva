package interfaces;

public interface advancedArithmetic {
	public abstract int divisorSum(int n);

}
