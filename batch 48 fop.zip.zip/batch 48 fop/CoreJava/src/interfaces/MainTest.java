package interfaces;

public class MainTest {

	public static void main(String[] args) {
		Message email=new Email();
		email.reveceived();
		System.out.println();
		email.sent();
		System.out.println();
		Message sms=new Sms();
		sms.reveceived();
		System.out.println();
		sms.sent();
	}

}
