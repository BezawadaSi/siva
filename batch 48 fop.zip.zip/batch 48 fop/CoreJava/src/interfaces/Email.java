package interfaces;

public class Email implements Message
{

	

	@Override
	public void reveceived() {
		System.out.println("Email received");
	}

	@Override
	public void sent() {
		System.out.println("email sent ");
	}
	
}