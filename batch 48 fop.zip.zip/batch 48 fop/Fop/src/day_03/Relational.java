package day_03;
import java.util.Scanner;
public class Relational {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c;
	  Scanner sc = new Scanner(System.in);
			a=sc.nextInt();
			b=sc.nextInt();
			c=sc.nextInt();
	
		System.out.println(a<b);
		System.out.println(a>c);
		System.out.println(a>=b);
		System.out.println(a<=c);
		System.out.println(a==b);
		System.out.println(b!=c);
		}

}
