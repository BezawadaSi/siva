package day_03;

public class Time {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      //convert minutes into years days hours minute
	  System.out.println(get_Data(3000010));	
		
		
		
		
	}
	public static String get_Data(long minutes)
	{
	
	long years=minutes/525600;
	long new_number=minutes % 525600;
	long days=new_number/1440;
    new_number= new_number%1440;
	long hours=new_number/60;
	new_number=new_number%60;
	minutes=new_number;
	return years+"  Years "+days+" days "+hours+" Hours "+minutes+" minutes ";
	
	}

}
