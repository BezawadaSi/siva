package day_03;
import java.util.Scanner;
public class Assigment {

	public static void main(String[] args) {
	int a,b;
	Scanner siva=new Scanner(System.in);
	a=siva.nextInt();
    b=siva.nextInt();
    System.out.println("assign :"+(a=b));
    System.out.println(a+=b);
    System.out.println(a-=b);
    System.out.println(a*=b);
    System.out.println(a/=b);
    System.out.println(a%=b);
    
	}

}
