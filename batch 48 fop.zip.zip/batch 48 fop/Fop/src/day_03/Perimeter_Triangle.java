package day_03;

public class Perimeter_Triangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("perimeter of triangle : "+get_PerimeterTriangle(5,8,9));

	}
    public static float get_PerimeterTriangle(int a,int b,int c)
    {
    	float perimeter= a+b+c;
    	return perimeter;
    }
	
	
}
