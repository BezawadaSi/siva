package day_03;
import java.util.Scanner;
public class Arthemetic {

	public static void main(String[] args) {
	  Scanner siva=new Scanner(System.in);
	  int a,b;
	  a=siva.nextInt();
	  b=siva.nextInt();
	  System.out.println("addition : "+(a+b));
	  System.out.println("sub : "+(a-b));
      System.out.println("mul : "+(a*b));
      System.out.println("div : "+(a/b));
      System.out.println("moudluas : "+(a%b));
	}

}
