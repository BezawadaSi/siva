package day_03;

public class Average {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.println(get_Avg(2,4,5,6));
    System.out.println(get_Avg(101,456,678,987));
    System.out.println(get_Avg(34,67,87,92));
	}
   public static float get_Avg(int a, int b, int c,int d)
   {
	float avg=a+b+c+d/4;
	return avg;
}
}