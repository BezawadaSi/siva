package day_03;

public class Kilometer_Meter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("kilometers into meters : "+get_Meter(20));

	}
	
	public static double get_Meter (float km)
	{
		double meter=km*1000;
		return meter;
		
		
	}

}
