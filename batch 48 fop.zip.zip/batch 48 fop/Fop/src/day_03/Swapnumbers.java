package day_03;

public class Swapnumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=17; int b=18;
		System.out.println(get_Swap( a,b));

	}
	public static String get_Swap(int a,int b) {
		a=a-b; b=b+a; a=b-a;
		return "after swap  "+a+"  and  "+b;
	}

}
