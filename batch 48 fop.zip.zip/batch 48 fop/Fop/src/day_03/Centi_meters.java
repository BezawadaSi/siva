package day_03;

public class Centi_meters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("meters into centimeters : "+get_Centimeters(100));

	}
    public static double get_Centimeters(float meters)
    {
    	double centimeters=100*meters;
    	return centimeters;
    }
}
