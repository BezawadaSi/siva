package day_03;

public class Area_Square {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("arae of square : "+ get_Areaofsquare(5));
        System.out.println("area of square : "+ get_Areaofsquare(7));
	}
	public static int get_Areaofsquare(int a)
	{
		int area=4*a;
		return area;
	}

}
