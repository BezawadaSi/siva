package day_03;

public class Milli_Meters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("centimeters to milli meters : "+get_Millimeters(29.5d));
		System.out.println("centimeters to milli meters : "+get_Millimeters(5678.565789d));
	}
    public static double get_Millimeters(double centimeter)
    {
    	double millimeter=centimeter*10;
    	return millimeter;
    }
}
