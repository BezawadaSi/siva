package day_03;

public class Perimeter_circle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("perimeter of circle : "+get_Perimeter(4));
		System.out.println("perimeter of circle : "+get_Perimeter(64));

	}
	public static double get_Perimeter(int r )
	{
		double perimeter=2*Math.PI*r;
		return perimeter;
	}

}
