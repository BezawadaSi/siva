package day_03;

public class Perimeter_Square {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("perimeter of square : "+get_Perimeterofsquare(20));
		System.out.println("perimeter of square : "+get_Perimeterofsquare(17));
	}
    public static int get_Perimeterofsquare(int a)
    {
    	int perimeter=4*a;
    	return perimeter;
    }
}
