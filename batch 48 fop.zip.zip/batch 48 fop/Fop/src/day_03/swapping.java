package day_03;

public class swapping {

	public static void main(String[] args) {
	//int a=10;
		String a="siva";
		//int b=20;
	    String b="krishna";
		System.out.println("after swapping :"+get_Number( a, b));

	}
	 public static String get_Number(String a,String b) {
		
		//int c=a;
		 String c=a;
		//a=b;
		 a=b;
		//b=c;
		 b=c;
		//return "after swap"+a+"and"+b;
		return a+"  and  "+b;
	
	}
	
}
