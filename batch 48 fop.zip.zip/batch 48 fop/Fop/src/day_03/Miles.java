package day_03;

public class Miles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(get_Miles(2500.0f,8,43,45));
		System.out.println(get_Miles(3340.5f,32,56,58));
				
				
	}				
    public static String get_Miles(float distance,int hr,int min,int sec)
    {
    	
    	float timeSeconds = (hr*3600) + (min*60) + sec;
		float mps = distance / timeSeconds;
		//float kph = ( distance/1000.0f ) / ( timeSeconds/3600.0f ); 
		double kph=(distance/timeSeconds)*3.6;
		double mph = kph / 1.609;
		 /* 
		  meters into kilometers km=meters/1000
		  we use hours =total seconds /3600
		 kmph=(distance(m)/1000)/(time(s)/3600) or distance(m)/time (sec)*3.6

		 */
		
		return "meters per second : "+mps+"\nkilo meter per hour : "+kph+" \nmeter per hour : "+mph;
		
    }
}
