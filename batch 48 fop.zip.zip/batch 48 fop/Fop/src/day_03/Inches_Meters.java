package day_03;

public class Inches_Meters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("inches to meters : "+get_Meters(12.3f));
		System.out.println("inches to meters : "+get_Meters(56.4f));

	}
  public static double get_Meters(float inches)
  {
	  double meters=inches/39.37;
	  return meters;
  }
}
