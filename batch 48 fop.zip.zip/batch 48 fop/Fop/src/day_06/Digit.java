package day_06;

public class Digit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_Data(4));
		System.out.println(get_Data(87));
		System.out.println(get_Data(420));
		System.out.println(get_Data(3956));
		System.out.println(get_Data(77290));
		System.out.println(get_Data(7729051));

	}
	public static String get_Data(int num)
	{
		String result="";
		if(num>=0 && num<9)
		{
			result="1 digit number.";
		}
		else if(num>9 && num<99)
		{
			result="2 digit number.";
		}
		else if(num>99 && num<999)
		{
			result="3 digit number";
		}
		else if(num>999 && num<9999)
		{
			result="4 digit number.";
		}
		else if(num>9999 && num<99999)
		{
			result="5 digit number.";
		}
		else 
		{
			result="number is more than 5 digit number.";
		}
		return result;
	}

}
