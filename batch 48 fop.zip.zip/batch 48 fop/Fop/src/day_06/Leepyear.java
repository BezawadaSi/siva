package day_06;

public class Leepyear {

	public static void main(String[] args) {
		System.out.println(get_year(2024));
		System.out.println(get_year(1800));

	}
	public static String get_year(int year)
	{
		String result="";
		if ( (year%4==0)&&(year%100!=0) ||(year%400==0))
		{
			result=year+" is a leep year.";
		}
		else
		{
			result=year+" is Not a leep year";
		}
		
    System.out.println("Bezawada.Sivakrishna");
		return result;
	}
	

}
