package day_06;

public class Operations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_Data(8,4,1));
		System.out.println(get_Data(6,3,2));
		System.out.println(get_Data(5,8,3));
		System.out.println(get_Data(7,8,4));

	}
	public static String get_Data(int a,int b,int num)
	{
		int c;
	String result="";
	if(num==1)
	{
		c=a+b;
		result="addition of two number :"+c;
	}
	else if(num==2)
	{
		c=a-b;
		result="substaction of two number :"+c;
	}
	else if(num==3)
	{
		c=a*b;
		result="multiplication of two numbers is :"+c;
	}
	else
	{
		result="wrong input";
	}
	return result;
}
}

