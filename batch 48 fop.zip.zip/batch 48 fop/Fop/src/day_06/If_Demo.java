package day_06;

public class If_Demo{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_Eligible(23));
		System.out.println(get_Eligible(18));
		System.out.println(get_Eligible(15));

	}
	public static String get_Eligible(int age)
	{
		String result="";
		if(age>18)
		{
			result="Eligible for vote.";
		}
	else if(age>=18)
	{
		result="just eligible for vote.";
	}
	else 
	{
		result="not eligible for vote.";
	}
	 return result;
}
}
