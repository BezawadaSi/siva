package day_06;

public class Even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_evenodd(46));
		System.out.println(get_evenodd(43));

	}
	public static String get_evenodd(int num)
	{    
		String result="";
		if(num%2==0)
		{
			result="given no "+num+"is even";
		}
		
		else
		{
			result="given number "+num+"is odd";
		}
		return result;	
		
	}
}
