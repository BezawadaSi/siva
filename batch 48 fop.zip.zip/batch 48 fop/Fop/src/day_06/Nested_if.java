package day_06;

public class Nested_if {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_blood(10,56.5f));
		System.out.println(get_blood(18,56.5f));
		System.out.println(get_blood(56,78.0f));

	}
	public static String get_blood(int age,float weight)
	{  
		String result="";
		 if(age>10)
		 {
			 if(weight>60)
			 {
				 result="he can give blood. ";
			 }
			 else
			 {
				 result="he can not give blood.";
			 }
		 }
		 else
		 {
			 result="he is not eligible to give blood.";
		 }
		 return result;

}
}
