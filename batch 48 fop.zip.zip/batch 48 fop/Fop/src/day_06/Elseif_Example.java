package day_06;

public class Elseif_Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_Power(1));
		System.out.println(get_Power(2));
		System.out.println(get_Power(3));
		System.out.println(get_Power(4));

	}
	public static String get_Power(int num)
	{
	String result="";
	if(num==1)
	{
	 result="2 power of 2 :"+Math.pow(2,2);
	}
	else if(num==2)
	{
		result="3 power of 3 :"+Math.pow(3,3);
	}
	else if(num==3)
	{
		result="4 power of 4 :"+Math.pow(4,4);
	}
	else 
	{
		result="wrong input";
	}
	return result;
}
}