package day_06;

public class Grades {

	public static void main(String[] args) {
			   System.out.println(get_Grade(67,45,67));
			   System.out.println(get_Grade(34,36,23));
			   System.out.println(get_Grade(87,98,100));
			}
	public static String get_Grade(int mark1,int mark2,int mark3 )
		  {     
			  String result="";
			  float percentage=(mark1 + mark2 + mark3) *0.33333f;
			  System.out.println(percentage);
			  
			  if(percentage>=90)
			  {
				  result="grade A.";
			  }
			  else if(percentage>=70 && percentage<90)
			  {
				  result="grade B.";
			  }
			  else if(percentage>=50 && percentage<70)
			  {
				  result="grade C.";
			  }
			  else 
			  {
				  result="grade F.";
			  }	

		return result;
		  }

}		
