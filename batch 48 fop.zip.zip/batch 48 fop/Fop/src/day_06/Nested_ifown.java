package day_06;

public class Nested_ifown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_pass(45,33,56));
		System.out.println(get_pass(34,38,56));
		System.out.println(get_pass(56,78,20));
		System.out.println(get_pass(45,39,56));

	}
 public static String get_pass(int math,int eng,int soc)
 {
	 String result="";
	 if(math>35)
	 {
		 if(eng>35)
		 {
			 if(soc>35)
			 {
				 result="pass All the subjects.";
			 }
			 else {
				 result="you fail in social subject.";
			 }
		 }
		 else 
		 {
			 result="you fail in english subject.";
		 }
	 }else 
	 {
		 result="you fail in maths subject";
	 }
	 
	 return result;
 }
}
