package day_06;

public class Nested_fh_cl {

	public static void main(String[] args) {
	System.out.println(get_Answer(1));
	System.out.println(get_Answer(2));

	}
public static String get_Answer(int ch)
{  
	String result="";
	if(ch==0)
	{  
	    float fahrenheat=56.04f;
		float celcius=( fahrenheat-32)*5/9;
		result="fashren heat to celcius heat :"+celcius;
	}
	else if(ch==1)
	{   
		float celcius=34.05f;
		float fahrenheat=( (celcius*9)/5)+32;
		result="celcius to fahren heat :"+fahrenheat;
	}
	else
	{
		result="wrong input";
	}
	return result;
}
}
