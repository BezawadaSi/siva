package day_06;

public class Gretest_threedigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_Number(45,43,23));
		System.out.println(get_Number(45,58,21));
		System.out.println(get_Number(45,43,98));

	}
 public static String get_Number(int a,int b,int c)
 {   
	 String result="";
	 if(a>b && a>c)
	 {
		 result="a is greter then  B and C :"+a;
	 }
	 else if(b>c)
	 {
		 result="B is greter than c  and a:"+b;
	 }
	 else
	 {
		 result="c is grether than a and b :"+c;
	 }
	 return result;
 }
}
