package day_06;

public class Three_Digit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_Digit(67));
		System.out.println(get_Digit(567));
		System.out.println(get_Digit(5674));

	}
	public static String get_Digit(int num)
	{
		String result="";
		if(num>99 && num<999)
		{
			result="3 digit number";
		}
		else
		{
			result="no 3 digit number";
		}
		return result;
	}

}
