package day_10_Assigments;

public class Program_6 {
	public static void main(String args[])   
	{ 
		System.out.println(get_value(6));
	}
	public static String get_value(int row)
	{
		String result="";
	int i, j;       
	for (i=0; i<row; i++)   
	{  
	for (j=row-i; j>1; j--)   
	{  
	System.out.print(" ");   
	}   
	
	for (j=0; j<=i; j++ )   
	{     
	System.out.print("* ");   
	}   
	System.out.println();   
	}   
	 return result;}   
	}  



