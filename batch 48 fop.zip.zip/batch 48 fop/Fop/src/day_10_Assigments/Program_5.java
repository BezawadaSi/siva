package day_10_Assigments;
import java.util.Scanner;
public class Program_5 {
	    public static void main(String ar[])  
	    {  
	        System.out.println("Pyramid Pattern: ");
	        System.out.println(get_values(6));
	        
	    }
	    public static String get_values(int nrows)
	    {String result=""; int rowCount = 1;  
	        for (int i = nrows; i > 0; i--)  
	        {  
	          
	            for (int j = 1; j <= i; j++)  
	            {  
	                System.out.print(" ");  
	            }  
	   
	            for (int j = 1; j <= rowCount; j++)  
	            {  
	                System.out.print(j+" ");  
	            }  
	   
	            System.out.println();  
	     rowCount++;  
	        }
	        return result;
	    }  
	}  