package day_10_Assigments;

public class Program_1 {

	public static void main(String[] args) {
		
		System.out.println(get_value(3));
	}
	public static String get_value(int num)
	{ String result="";
		for (int i=1;i<=num;i++)
		{
			for (int j1=1;j1<=5;j1++)
			{
				System.out.print(j1);
			}
			System.out.println();
		}
		return result ;
	} 
}