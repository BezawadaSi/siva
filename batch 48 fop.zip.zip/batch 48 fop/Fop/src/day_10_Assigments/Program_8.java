package day_10_Assigments;

public class Program_8 {
	public static void main(String[] args)   
	{   
		System.out.println(get_values(6));
	}
	public static String get_values(int rows)
	{
	int i, j;  
	String result="";
	
	for (i = 1; i <= rows; i++)   
	{  
	for (j = 1; j <= i; j++)  
	{  
	System.out.print(i);  
	}  
	System.out.print("");  
	}
	return result;
	} 
	
	}  


