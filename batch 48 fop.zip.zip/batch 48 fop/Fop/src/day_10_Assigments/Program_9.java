package day_10_Assigments;

public class Program_9 {
	public static void main(String[] args) 
	{  
		System.out.println(get_value(6));
	}
	public static String get_value(int size)
	{
	int letter = 65; String result="";//ASCII value of capital A is 65  
	//inner loop for rwos  
	for (int i = 0; i<= size; i++)  
	{  
	//outer loop for columns  
	for (int j = 0; j <= i; j++)  
	{  
	//prints the character  
	System.out.print((char) letter);  
	}  
	letter++;  
	System.out.print("");  
	}
	return result;
	} 
	}  


