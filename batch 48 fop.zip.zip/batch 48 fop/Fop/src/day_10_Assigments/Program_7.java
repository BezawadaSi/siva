package day_10_Assigments;
import java.util.*;
public class Program_7 {

	 public static void main(String args[]) {
		    // size
		   
		   System.out.println(get_values(5));

	 }    // printing square
		    public static String get_values(int size)
		    { int alpha = 65;String result="";
		    for (int i = 0; i < size; i++) {
		      for (int j = 0; j < 3; j++) {
		        System.out.print((char)(alpha+j));
		      }
		      System.out.print(" ");
		    }
		    return result;
		  }
		}

