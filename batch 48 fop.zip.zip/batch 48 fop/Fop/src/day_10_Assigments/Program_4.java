package day_10_Assigments;

public class Program_4   
{   
public static void main(String args[])   
{  
	System.out.println(get_value(6));
}
public static String get_value(int row) {
int i, j; String result="";   
  
for(i=row; i>=0; i--)   
{   

for(j=0; j<=i; j++)   
{   
  
System.out.print("* ");   
}   
System.out.println();   
}return result;   
}   
}