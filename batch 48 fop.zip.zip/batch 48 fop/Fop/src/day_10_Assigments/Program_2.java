package day_10_Assigments;

public class Program_2 {
public static void main(String[] args) {
		
		System.out.println(get_value(3));
	}
	public static String get_value(int num)
	{ String result="";
	  int alphabet=96;
		for (int i=1;i<=num;i++)
		{
			for (int j1=1;j1<=6;j1++)
			{
				System.out.print((char) (alphabet+j1) + " ");
			}
			System.out.println();
		}
		return result ;
	} 
}


