package day_11;

public class V_alphabet {

	public static void main(String[] args) {
		
System.out.println(get_v(5));
	}
public static String get_v(int num)
{ 
	String result="";
	for (int r=1;r<=num;r++)
	{ 
		for(int c=1;c<=9;c++)
		{
			if(r==c || c+r==10)
			{
				System.out.print("*");
			}
			else
			{
				System.out.print(" ");
			}
		}
		System.out.println();
	}
	return result;
}

}
