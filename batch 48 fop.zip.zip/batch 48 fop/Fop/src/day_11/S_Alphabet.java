package day_11;

public class S_Alphabet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	System.out.println(get_S(5));
	}
	public static String get_S(int num)
	{ String result="";

	for (int r=0;r<=num;r++)
	{
		for(int c=0;c<=num;c++)
		{
			if( r==0||r==num/2+1||r==num||(r==1&&c==0 ||r==2 && c==0)||(r==4 && c==num))
			{ 
		System.out.print("*");
			}
			else
			{
				System.out.print(" ");
			}
			
		}System.out.println();
	} 
	return result;
	}
}

