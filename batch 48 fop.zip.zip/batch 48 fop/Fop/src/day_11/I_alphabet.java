package day_11;

public class I_alphabet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(get_I(6));
	}
public static String get_I(int num)
{ 
	String result="";
	for (int r=1;r<=num;r++)
	{ 
		for(int c=1;c<=num;c++)
		{
			if(r==1|| r==num || c==num/2)
			{
				System.out.print("*");
			}
			else
			{
				System.out.print(" ");
			}
		}
		System.out.println();
	}
	return result;
}

}
