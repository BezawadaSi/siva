
package day_11;

public class W_alphabet {

	public static void main(String[] args) {
		System.out.println(get_alphabet(5));
	}
	public static String get_alphabet(int num)
	{
		String result="";
	for(int r=1;r<=num;r++)
	{
		for (int c=1;c<=num;c++)
		{
			if(  c==1 || c==num ||(r==c && r>2)|| (r==4 && c==2) )
					{
				result+="*";

					}
			else 
			{
				result+=" ";
			}
		}result+="\n";
	}
	return result;
	}

}
