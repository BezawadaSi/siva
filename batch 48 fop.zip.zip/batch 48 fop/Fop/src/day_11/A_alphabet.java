package day_11;

public class A_alphabet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(get_A(6));
	}
public static String get_A(int num)
{ 
	String result="";
	for (int r=1;r<=num;r++)
	{ 
		for(int c=1;c<=num;c++)
		{
			if(r==1 || r==num/2+1 || c==1 || c== num)
			{
			result+="*";
			}
			else
			{
				result+=" ";
			}
		}
		result+="\n";
	}
	return result;
}


}

