package day_11;

public class Y_alphabet {

	public static void main(String[] args) {
		System.out.println(get_alphabet(5));
	}
	public static String get_alphabet(int num)
	{
		String result="";
	for(int r=1;r<=num;r++)
	{
		for (int c=1;c<=num;c++)
		{
			if( (r==c && r<=3)||(c==3 && r>3) || (r+c==6 && r<=3))
					{
				result+="*";

					}
			else 
			{
				result+=" ";
			}
		}result+="\n";
	}
	return result;
	}

}
