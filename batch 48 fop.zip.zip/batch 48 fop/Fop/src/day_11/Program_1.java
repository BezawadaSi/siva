package day_11;

public class Program_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(print_prime(100));
	}
 public static boolean get_value(int end)
 {  int a,b,count=0; String result="";
 
 
 for (b=1;b<=end;b++)
 {
 if (end%b == 0)
 count++;
 }
 if(count == 2)
 return true;
 else
 return false;
 }
 public static String print_prime(int num)
 { String result="";
	 for(int i=0;i<=num;i++)
 {
	 if(get_value(i))
	 {
		 result+=","+i;
	 }
 }
 return result;
 }
	 
 }