package day_02;

public class Impilicit_Typecasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		long b=a;
		double c=b;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);

	}

}
