package day_02;

public class Type_Pramotion {
	public static void main(String[] args) {
		byte a=20;
		byte b=50;
		byte c=(byte)(a+b); 
	   //byte ,short,chararater we can not store 2 byte short char in another chat short byte
	
	  System.out.println(c);
	  int x=50;
	  float y=15.5f;
	  float z= x/y;
	  System.out.println(z);
	
	}
	
}
