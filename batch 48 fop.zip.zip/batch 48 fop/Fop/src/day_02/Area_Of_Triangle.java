package day_02;

public class Area_Of_Triangle {
    public static void main(String args[]) {
    	System.out.println(get_Area_Of_Triangle(2,4));
    	System.out.println(get_Area_Of_Triangle(5,6));
    }
    
    public static double get_Area_Of_Triangle(int b,int h) {
    	
    double result=0.5*b*h;
    return result;
    }
    
}

