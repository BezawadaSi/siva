package day_02;

public class Area_Of_Circle {
	public static void main(String[] args) {
	
		System.out.println(get_Areaofcircle(5));
		System.out.println(get_Areaofcircle(8));
		System.out.println(get_Areaofcircle(7));
	}
   public static double get_Areaofcircle(int r) {
	   double pie=3.14;
	  //double result=math.PI*r*r;
	   double result=pie*r*r; 
	   return result;
   }
}
