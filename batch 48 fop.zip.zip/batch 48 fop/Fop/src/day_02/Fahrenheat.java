package day_02;

public class Fahrenheat {

	public static void main(String[] args) {
		System.out.println(get_Celcius(43));
		System.out.println(get_Celcius(23.5f));
		System.out.println(get_Celcius(35));
    
	}
	public static float get_Celcius(float fahrenheat) {
		
		float celcius=(fahrenheat-32)*5/9;
		return celcius;	
	}
}
