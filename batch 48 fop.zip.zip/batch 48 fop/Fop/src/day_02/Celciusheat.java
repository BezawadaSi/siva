package day_02;

public class Celciusheat {

	public static void main(String[] args) {
	  System.out.println(get_Fahrenheat(13));
      System.out.println(get_Fahrenheat(23));
	}
	public static float get_Fahrenheat(float celcius) {
		 float fahrenheat=( (celcius*9)/5)+32;
		return fahrenheat;
	}

}
