package day_02;

public class Ascii_Value {
	public static void main(String[] args) {
		// 48 to 57 --->0 to 9
		// 65 to 90 --->A to Z
		//97 to 122 --->a to z
	}

}
