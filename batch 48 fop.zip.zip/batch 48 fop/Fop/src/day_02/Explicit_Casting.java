package day_02;

public class Explicit_Casting {
	public static void main(String[] args) {
		int a=10;
		byte b=(byte)a;
		double c=34.78;
		byte d=(byte)c;
		
		System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(47-2+8*45*(65+3)/98+3);
	}

}
