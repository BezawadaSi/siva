package day_01;
import java.util.Scanner;
public class Person_Details {

	public static void main(String[] args) {
	 byte age=23; 
	 String name="Siva krishna"; 
	 long mobileno=772905169; 
	 String gender="m"; 
	 String emailid="bsiva4550@gmail.com"; 
	 String address="ongole"; 
	 float height=5.6f; 
	 int salary=30000; 
	 String maritalstatus="unmaried";
	
	
	 System.out.println(name +" "+ age+" " +gender+" "+address+" "+mobileno+" "+maritalstatus+" "+salary+" "+emailid+" "+height);
	 System.out.println(name +'\n'+ age+'\n' +gender+'\n'+address+'\n'+mobileno+'\n'+maritalstatus+'\n'+salary+'\n'+emailid+'\n'+height);
	 
	 Scanner siva=new Scanner(System.in);
	 name=siva.next();
	 age=siva.nextByte();
	 gender=siva.next();
	 address=siva.next();
	 mobileno=siva.nextLong();
	 maritalstatus=siva.next();
	 salary=siva.nextInt();
	 emailid=siva.next();
	 height=siva.nextFloat();
	 System.out.println("name ;" +name +'\n'+ "age:"+age+'\n'+"gender:" +gender+'\n'+"address"+address+'\n'+"mobileno:"+mobileno+'\n'+"marital staus:"+maritalstatus+'\n'+"salary:"+salary+'\n'+"emailid:"+emailid+'\n'+"height:"+height);
		 
	 

	}

}
