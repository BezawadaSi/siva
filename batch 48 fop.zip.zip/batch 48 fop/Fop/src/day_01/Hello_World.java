package day_01;

public class Hello_World {

	public static void main(String[] args) {
	/*	System.out.println("Hello world");
		System.out.println("hello java");
		System.out.println("Welcome to Bezawada Sivakrishna");
		int a=10 ,b=3, c= 13,d =8,e =34,max,max1;
		
		max = (a > b && a > c && a > d) ?  
		         a : ((b > c && b > d) ?
		         b : (c > d ? c : d));
		 
	       max1= (a>b && a>c && a>d && a>e )?
	             a : ((b>c && b> d && b> e)?
	           b: ((c>d && c> e ) ?
	             c : (d>e) ? d :e)); 
	       
	       System.out.println(max);
	       System.out.println(max1);
	       */
	       int m1 =40,m2=56,m3 = 23;
	       int total = m1+m2+m3;
	       float avg=m1=m2+m3/3;
	       System.out.println(avg);
	       System.out.println(total);
	        if(m1>=35&&m2>=35&&m3>=35)
	       {
	    	   System.out.println("Pass ");
	    	  
	    	   if (avg >= 60  )
	    	   {
	    		   System.out.println(" first place ");
	    	   }
	    	   else if (avg >= 50 && avg <60)
	    	   {
	    		   System.out.println(" second class");
	    	   }
	    	   else if (avg < 50 && avg >= 40)
	    	   {
	    		   System.out.println("third place");
	    	   }
	        
	       }
	        else 
	    		   System.out.println("fail");      
	             
      
	}

}
