package day_07;

public class Switch1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_switch('*',4,6));

	}
 public static String get_switch(char ch,int a,int b)
 {
	 String result;
	 switch(ch)
	 {
	 case '+':
	 {
		result="add two numbers :"+(a+b);
		 break;
	 }
	 case '-':
	 {
		 result="subb : "+(a-b);
		 break;
	 }
	 case '*':
	 {
		 result="mul : "+(a*b);
		 break; 
	 }
	 case '/':
	 {
		 result="div : "+(a/b);
		 break;  
	 }
	 case '%':
	 {
		 result="percent  :"+(a%b);
		 break;
	 }
	 default:
	 {
		 result="wrong output";
	 }
	 
	 }
	 return result;
 }
}
