package day_07;

public class Even_Switch {

	public static void main(String[] args) {
		System.out.println(get_num(1,4));
		System.out.println(get_num(2,5));

	}
	public static String get_num(int num,int val)
	{  String result="";
		switch(num)
		{
		case 1:
		{     if(val%2==0)
			result="even :"+val;
			break;	
			
		}
		case 2:
		{    if(val%2!=0)
			result="odd :"+val;
		break;
		}
		default:
		{
			result="wrong input";
		}
		}
		return result;
	}

}
