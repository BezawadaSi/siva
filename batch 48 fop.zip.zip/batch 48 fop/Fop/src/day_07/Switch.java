package day_07;
import java.util.Scanner;
public class Switch {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter numver");
	
	/*int a = sc.nextInt();
	
	switch (a) {
	case 3:{
	
		System.out.println("Three");
		break;
	}
	case 1:
	{
    
		System.out.println("one");
		break;
	}
	case 2:
	{
		System.out.println("Two");
		break;
	}
	case 4:
	{
		System.out.println("Four");
		break;
	}
	case 5:
	{
		System.out.println("Five");
		break;
	}
	case 6:
	{
		System.out.println("six");
		break;
	}
	case 7:
	{
		System.out.println("seven");
		break;
	}
	default:
	{
		System.out.println("wrong input");
	}
	}*/
	/*
	System.out.println("enter fruit name");
	String fruit = sc.nextLine();

    switch (fruit) {
        case "apple":
            System.out.println("Apples are red.");
            break;
        case "banana":
            System.out.println("Bananas are yellow.");
            break;
        case "orange":
            System.out.println("Oranges are orange.");
            break;
        case "grape":
            System.out.println("Grapes are purple.");
            break;
        default:
            System.out.println("I don't know that fruit.");
            break;

	}*/
    
    
	String num = sc.nextLine();

    switch (num) {
        case "zero":
            System.out.println(0);
            break;
        case "one":
            System.out.println(1);
            break;
        case "two":
            System.out.println(2);
            break;
        case "three":
            System.out.println(3);
            break;
        case "four":
            System.out.println(4);
            break;
        case "five":
            System.out.println(5);
            break;
        case "six":
            System.out.println(6);
            break;
        case "seven":
            System.out.println(7);
            break;
        case "eight":
            System.out.println(8);
            break;
        case "nine":
            System.out.println(9);
            break;
        case "ten":
            System.out.println(10);
            break;
        default:
            System.out.println("enter zero to ten only");
            break;

	}


}
}
