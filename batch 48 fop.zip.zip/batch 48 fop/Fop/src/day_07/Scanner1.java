package day_07;
import java.util.Scanner;
public class Scanner1 {

	public static void main(String[] args) {
		
		int a,b;
		System.out.println("enter a and b values");
		Scanner siva=new Scanner(System.in);
		a=siva.nextInt();
		b=siva.nextInt();
		System.out.println(a+=b);
		System.out.println("enter char" );
		char ch=siva.next().charAt(0);
		System.out.println(ch);

	}

}
