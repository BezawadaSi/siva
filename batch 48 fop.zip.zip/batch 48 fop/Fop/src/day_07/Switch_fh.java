package day_07;

public class Switch_fh {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_value(1));
		System.out.println(get_value(2));
		//System.out.println(get_value(3));

	}
 public static String get_value(int num)
 {
	 String result="";
	 switch (num)
	 {
	 case 1:
	 {
		 float fahrenheat=56.04f;
		 float celcius=( fahrenheat-32)*5/9;
			result="fashren heat to celcius heat :"+celcius;
			break;
	 }
	 case 2:
	 {
		 float celcius=34.05f;
			float fahrenheat=( (celcius*9)/5)+32;
			result="celcius to fahren heat :"+fahrenheat;
			break;
	 }
	 default:
	 {
		 result="wrong input";
	 }
	 }
	return result; 
	 
 }
 







}
