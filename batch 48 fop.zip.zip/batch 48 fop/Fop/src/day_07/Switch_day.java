package day_07;

public class Switch_day {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_day(1));
		//System.out.println(get_day(3));
		System.out.println(get_day(7));
		System.out.println(get_day(7));
		System.out.println(get_day(8));
		//System.out.println(get_day(89));

	}
 public static String get_day(int num)
 {
	 String result="";
	 switch(num)
	 {
	 case 1:{
		 result="monday";
		 break;
	 }
     case 2:{
	 result="tuesday";
	 break;
    }
     case 3:{
	 result="wednesday";
	 break;
     }
    case 4:{
	 result="thursday";
	 break;
     }
     case 5:{
	 result="friday";
	 break;
     }
     case 6 :
     //{
	 //result="enjoy";
	// break;
     //}
     case 7:
     {
	 result="holiday";
	 break;
    }
     default:
     {
    	 result="wrong output";
     }
 }
	 return result;
}
}