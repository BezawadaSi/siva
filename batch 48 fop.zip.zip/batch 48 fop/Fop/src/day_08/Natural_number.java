package day_08;

public class Natural_number {

	public static void main(String[] args) {
		
      System.out.println(get_number(50));
	}
  public static int get_number(int num)
  {
	  int i=1;
	  int sum=0;
	  while(i<=num)
	  {
		  sum=sum+i;
		  i++;
	  }
    return sum; }
}
