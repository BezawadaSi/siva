package day_08;

public class For_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 System.out.println(get_Number(4567));
	}
 public static String get_Number(int num)
 {   int sum;
   int num1=num;
	 //for (sum=0;num>0;sum=sum+num%10,num=num/10);
	 for(sum=0;num>0;sum=(sum*10)+num%10,num=num/10);
		
	//return sum; 
	return (num1==sum)?"palimdrome":"not palimdrome";  
	  
 }  
}
