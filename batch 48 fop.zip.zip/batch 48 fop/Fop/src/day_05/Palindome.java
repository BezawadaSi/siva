
package day_05;

public class Palindome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(get_Palindrome(454));
System.out.println(get_Palindrome(4554));
	}
  public static String get_Palindrome(int num)
  {
	 int r,sum=0;   // poli=a%100;             one digt=num%100
	 int temp=num;   //res1=poli%10;           hundigit=num/100
	 while(num>0)    //res2=res1*100;
	 {             //res3=poli/10;
	 r=num%10;     //res4=res3*10;
	 sum=(sum*10)+r; //res5=a/100;
	 num=num/10;     //res6=res5*1;    
	 }
	 return (temp==sum)?"palimdrome":"not palimdrome";  // res2+res4+res6
	  
	  
	  
	  
  }
}
