package day_05;

public class Reverse_Number {

	public static void main(String[] args) {
		System.out.println(get_Data(345));
		System.out.println(get_Data(3454));

	}
    public static int  get_Data(int num)
    {
    	 int r,sum=0;
    	 while(num>0)
    	 {
    		 r=num%10;
    		 sum=(sum*10)+r;
    		 num=num/10;
    	 }
    	 return sum;
    } 
    
}
