package day_05;

public class Bitwise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int a=5;
    int b=6;
    int c=-10;
    System.out.println(a&b);
    System.out.println(a|b);
    System.out.println(a^b);
    System.out.println(~a);
    System.out.println(~b);
    System.out.println(~c);
	}

}
