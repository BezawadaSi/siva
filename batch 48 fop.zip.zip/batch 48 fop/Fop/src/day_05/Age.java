package day_05;
import java.util.Scanner;
public class Age {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

  System.out.println(get_Data(18));
  System.out.println(get_Data(27));
	}
  public static String get_Data(int age)
  {
	   String result=age>18?"eligible":"not eligible";
	   return result;
  }
}
