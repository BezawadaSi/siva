package day_05;

public class Ternary {

	public static void main(String[] args) {
		int a=10; int b=20;
		int result=(a<b)? a:b;
		System.out.println("result="+result);
		

	}

}
