package day_05;

public class Ternarymul {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.println(get_Data(10,2));
    System.out.println(get_Data(5,4));
    System.out.println(get_Data(2,5));
	}
	
	
	public static String get_Data(int a,int b)
	{
	    int mul=a*b;
		String result=(mul==20)?"good":"bad";
		return result;
	}

}
