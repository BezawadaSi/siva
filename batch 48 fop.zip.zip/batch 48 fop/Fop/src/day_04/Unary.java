package day_04;

public class Unary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int a=10;int b=20;
		/*System.out.println(a);
		int value =++a;
		System.out.println(value);
		int value1=a++;
		System.out.println(value1);
		*/System.out.println(a);
  System.out.println(++a + b++ + ++b + a++ + a);
	
	}

}
