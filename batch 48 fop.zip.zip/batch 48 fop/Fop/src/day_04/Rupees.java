package day_04;

public class Rupees {

	public static void main(String[] args) {
  System.out.println(get_Rupees(5678934));
  System.out.println(get_Rupees(56789344));
  System.out.println(get_Rupees(986735621));
	}
   public static String get_Rupees(int cash)
   {
	   int  tt=cash/2000;
	    cash=cash%2000;   
	    int tw=cash/1000;     
	    cash=cash%1000;
	    int twohun=cash/200;
	    cash=cash%200;
	    int five=cash/500;    
	    cash=cash%500;       
	    int hun=cash/100;   
	    cash=cash%100;    
	    int fif=cash/50; 
	    cash=cash%50;     
	    int twn=cash/20;  
	    cash=cash%20;     
	    int ten=cash/10;   
	    cash=cash%10;     
	    int fiverupees=cash/5; 
	    cash=cash%5;    
	    int two=cash/2;    
	    cash=cash%2;        
	    int one=cash/1; 
	    cash= cash%1 ;        
return "2000 notes are : " +tt+"\n1000 notes are : "+tw+"\n 200 notes are : "+twohun+"\n500 notes are : "+five+"\n100 notes are : "+hun+"\n50 notes are : "+fif+"\n 20 notes are : "+twn+"\n 10 notes are : "+ten+"\n 5 conis : "+fiverupees+"\n 2 coins are : "+two+"\n 1 coins are : "+one;

}
}
