package day_04;

public class Logical {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10;
		int b=20;
		int c=23;
		System.out.println((a>b)&&(b>c));
		System.out.println((a>b)||(b>c));
		System.out.println(a>b);
		System.out.println(a<b);
		System.out.println((a<b)^(b>c));
		System.out.println((a<b)^(b<c));
		System.out.println((a>b)^(b>c));
		System.out.println((a<b)^(a>c));
		
		
		
		
		
		/*  and                 or
		 *  t and t =t     f or f =f
		 *  t and f= f     t or f = t
		 *  f and t =f     f or t=t
		 *  f and f =f     t or t =t
		 */
	}

}
