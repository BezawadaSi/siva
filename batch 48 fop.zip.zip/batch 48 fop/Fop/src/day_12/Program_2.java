package day_12;

public class Program_2 {

	public static void main(String[] args) {
		 int siva[]= {1,2,3,4,5,6,2,3,4,5,1,1,1,3,3,32,2,2,78,77,66,54,54,54};
		 System.out.println(get_grade( siva));
	}
public static String  get_grade(int siva[])
{   String result=""; int count=0; 
	for (int i=0;i<siva.length;i++)
	{
		if(siva[i]==2)
		{
			 count++;
		}
	result=count+" are total values ";
		 
	}
	return result;
}
}
