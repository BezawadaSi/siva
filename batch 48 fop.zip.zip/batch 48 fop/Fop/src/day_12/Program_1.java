package day_12;

public class Program_1 {

	public static void main(String[] args) {
		 int siva[]= {99,45,9,25,78,95};
		 System.out.println(get_grade( siva));
	}
public static String  get_grade(int siva[])
{ int sum=0;  String result="";
	for (int i=0;i<siva.length;i++)
	{
		
		 sum+=siva[i]/600;
		 
	}
	if(sum>80 && sum <=100)
	{
		result="A grade";
	}
	else if(sum>60 && sum<=80)
	{
		result="B grade";
	}
	else 
	{
		result="c grade";
	}
	return result;
}
}
