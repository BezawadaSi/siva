package day_12;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Maximum_2 {

	public static void main(String[] args) {
		int siva[]= {12,34,21,54,67,32,78};
		Arrays.sort(siva);
	
	int n=siva.length;
	System.out.println("second maximum number is :"+siva[n-2]);
}

}
