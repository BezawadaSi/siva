package day_12;

public class Sum_Of_Elements {

	public static void main(String[] args) {
	
  int siva[]= {12,34,2,24,5,53,3,33,3,3};
  System.out.println(get_value(siva));
	}
public static int get_value(int siva[])
{ int sum=0;
	for (int i=0;i<siva.length;i++)
	{
		sum=sum+siva[i];
	}
	return sum;
}
}
