package day_12;

public class Minimum_value {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int siva[] = {25, 11, 7, 75, 56,78};
		 System.out.println("the maximum value is :"+get_value(siva));
}
public static int get_value(int siva[])
{     int min = siva[0];  
	 for (int i = 0; i < siva.length; i++)
	 {  
		 if(siva[i] < min) 
		 {   
			 min = siva[i];    
         }
}
	 return min;
}
}

