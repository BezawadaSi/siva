package day_12;
import java.util.Scanner;
public class Key_value
{
    public static void main(String[] args) 
    {
        int n, i = 0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter no. of elements you want in array:");
        n = s.nextInt();
        int a[] = new int[n];
        System.out.println("Enter all the elements:");
        for(i = 0; i < n; i++)
        {
            a[i] = s.nextInt();
        }
       System.out.println(get_value(a,5));
    }
    public static String get_value(int a[],int x)
    {  int flag=0; String result=""; int i;
        for( i = 0; i < a.length; i++)
        {
            if(a[i] == x)
            {
                flag = 1;
                break;
            }
            else
            {
                flag = 0;
            }
        }
        if(flag == 1)
        {
            result="Element found at position:"+(i+1);
        }
        else
        {
            result="Element not found";
        }
        return result;
    }
}
