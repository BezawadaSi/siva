package day_12;

public class Email_star {

	public static void main(String[] args) {
		String email="bsiva4550@gmail.com";
		StringBuffer email1=new StringBuffer("bsiva4550@gmail.com");
		System.out.println(email);
		System.out.println(email1.replace(1, 8, "*******"));

	}

}
