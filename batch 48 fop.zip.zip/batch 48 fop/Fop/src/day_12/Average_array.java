package day_12;

import java.util.Scanner;

/*
 * Calculating the average of a given integer Array,
 * taking the array elements from user.
 */
public class Average_array {
 
    public static void main(String[] args) {
 
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of the Array: ");
        int n = sc.nextInt();
       int arr[] = new int[n];
       System.out.println("Enter " + n + " element(s) of the Array: ");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        System.out.println(get_values(arr));
    }
   public static String get_values(int arr[])
   {  int sum=0;float average;String result="";
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
      average = (float) sum / arr.length;
       result+="The average of the given Array: " + average;
       return result;
    } 
 
}