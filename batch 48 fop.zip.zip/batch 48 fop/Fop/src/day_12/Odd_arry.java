package day_12;
import java.util.Scanner;
public class Odd_arry {
	public static void main(String[] args) 
	{
		int Size, i;
		Scanner sc = new Scanner(System.in);
	 
		System.out.print(" Please Enter Number of elements in an array : ");
		Size = sc.nextInt();	
		
		int [] a = new int[Size];
		
		System.out.print(" Please Enter " + Size + " elements of an Array  : ");
		for (i = 0; i < Size; i++)
		{
			 a[i] = sc.nextInt();
		} 
		System.out.println(get_value(a));
		
	}
	public static String get_value(int a[])
	{ 
		int oddCount=0;
	String result,result1="";
	
		result=" List of  Odd Numbers in this Array are :"; 
		for(int i = 0; i < a.length; i++)
		{
			if(a[i] % 2 != 0)
			{
				result+=a[i] +" ";
				oddCount++;
			}
		}		
		
		result+="\n Total Number of Odd Numbers in this Array = " + oddCount;
		return result;
		}
}