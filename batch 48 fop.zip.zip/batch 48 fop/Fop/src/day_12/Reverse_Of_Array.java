package day_12;

public class Reverse_Of_Array {

	public static void main(String[] args) {
		 int [] siva = new int [] {1, 2, 3, 4, 5};  
System.out.println(get_value( siva));
	}
public static String get_value(int siva[])
{    
	String result,result1="";
	result="original array :";
	for (int i = 0; i < siva.length; i++) 
	{ 
		result+=siva[i] + " ";
	}
	
	result1="after reverse of array is :";
	 for (int j = siva.length-1; j >= 0; j--) 
	 {
		result1+=siva[j] + " "; 
	 }
	 return result+"\n"+result1;
    }

}
