package day_12;
import java.util.Scanner;
public class Even_number_array {
	public static void main(String[] args) 
	{
		int Size, i;
		Scanner sc = new Scanner(System.in);
	 
		System.out.print(" Please Enter Number of elements in an array : ");
		Size = sc.nextInt();	
		
		int [] a = new int[Size];
		
		System.out.print(" Please Enter " + Size + " elements of an Array  : ");
		for (i = 0; i < Size; i++)
		{
			 a[i] = sc.nextInt();
		} 
		System.out.println(get_value(a));
		
	}
	public static String get_value(int a[])
	{ 
		int evenCount=0;
	String result,result1="";
	
		result=" List of Even Numbers in this Array are :"; 
		for(int i = 0; i < a.length; i++)
		{
			if(a[i] % 2 == 0)
			{
				result+=a[i] +" ";
				evenCount++;
			}
		}		
		
		result+="\n Total Number of Even Numbers in this Array = " + evenCount;
		return result;
		}
}