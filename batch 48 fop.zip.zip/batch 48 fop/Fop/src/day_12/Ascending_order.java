package day_12;

public class Ascending_order {
	  public static void main(String[] args) {        
          
	        //Initialize array     
	        int [] siva =  {5, 2, 8, 7, 1}; 
	        System.out.println(get_value(siva));
	  }
	  public static String get_value(int siva[])
	  {
	        int temp = 0;    
	         String result="";   
	         
	       
	        for (int i = 0; i < siva.length; i++)
	        {     
	            for (int j =i+ 1; j < siva.length; j++) 
	            {     
	               if(siva[i] > siva[j])
	               {    
	                   temp = siva[i];    
	                  siva[i] = siva[j];    
	                   siva[j] = temp;    
	               }     
	            }     
	        }    
	         result="\n";  
	         result="Elements of array sorted in ascending order: ";
	         for (int i = 0; i < siva.length; i++) 
	         {     
	        	 result=result+siva[i] + " "; 
	          }    
	    
return result;
}
    
}

