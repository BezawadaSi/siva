package day_12;

//public class Project {
	
	import java.util.Scanner;

	public class Project {

		public static void main(String[] args) {
			Scanner sb=new Scanner(System.in);
			System.out.println("Enter the input: ");
			String input= sb.next();
			System.out.println(get_String(input));
		}
		public static  String get_String(String name){
			String result="";
			for (int i =0;i<name.length();i++){
				result+=get_Letters(name.charAt(i));//+"\n";

			}
			return result;
		}
		public static String get_Letters(char ch){
			int num =5;
			if (ch=='A'||ch=='a'){
				String result = "";
				for (int i =1;i<=num;i++){
					for(int j =1;j<=num;j++){
						if (i==1||j==1||j==5||i==(num+1)/2){
							result+="A";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if (ch=='B'||ch=='b'){
				String result = "";
				for (int i =1;i<=num;i++){
					for(int j =1;j<=num;j++){
						if (i==1||j==1||j==5||i==(num+1)/2||i==5){
							result+="B";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if (ch=='C'||ch=='c'){
				String result = "";
				for (int i =1;i<=num;i++){
					for(int j =1;j<=num;j++){
						if (i==1||i==num||j==1){
							result+="c";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if (ch=='D'||ch=='d'){
				String result = "";
				for (int i =1;i<=num;i++){
					for(int j =1;j<=num;j++){
						if (j==1||i==1&&j==2||i==1&&j==3||i==1&&j==4||i==2&&j==5||i==3&&j==5||i==4&&j==5||i==5&&j==2||i==5&&j==3||i==5&&j==4){
							result+="D";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if (ch=='E'||ch=='e'){
				String result = "";
				for (int i =1;i<=num;i++){
					for(int j =1;j<=num;j++){
						if (i==1||j==1||i==num||i==(num+1)/2){
							result+="E";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if (ch=='F'||ch=='f'){
				String result = "";
				for (int i =1;i<=num;i++){
					for(int j =1;j<=num;j++){
						if (i==1||j==1||i==(num+1)/2){
							result+="F";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if (ch=='G'||ch=='g'){
				String result="";
				for(int i=1;i<=num;i++){
					for(int j=1;j<=num;j++){
						if(i==1||j==1||i==5||(i==4&&j==5)||(i==3&&j==5)||(i==3&&j==3)||(i==3&&j==4)){
							result+="G";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if (ch=='H'||ch=='h'){
				String result="";
				for(int i=1;i<=num;i++){
					for(int j=1;j<=num;j++){
						if(j==1||j==5||i==3){
							result+="H";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if (ch=='I'||ch=='i'){
				String result="";
				for(int i=1;i<=num;i++){
					for(int j=1;j<=num;j++){
						if(i==1||j==3||i==5){
							result+="I";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if(ch=='J'||ch=='j'){
				String result="";
				for(int i=1;i<=num;i++){
					for(int j=1;j<=num;j++){
						if(i==1||j==3||(i==5&&j==2)||(i==5&&j==1)||(i==4&&j==1)){
							result+="J";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if(ch=='K'||ch=='k'){
				String result="";
				for(int i=1;i<=num;i++){
					for(int j=1;j<=num;j++){
						if(j==1||(i==3&&j==2)||(i==2&&j==3)||(i==4&&j==3)||(i==1&&j==4)||(i==5&&j==4)){
							result+="K";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if(ch=='L'||ch=='l'){
				String result = "";
				for (int i =1;i<=num;i++){
					for(int j =1;j<=num;j++){
						if (j==1||i==num){
							result+="L";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}

			if (ch=='M'||ch=='m'){
				String result = "";
				for (int i = 0; i < 6; i++) {
					for (int j = 0; j < 11; j++) {
						if (j == 0 || j == 10 || j == i || j == 10 - i) {
							result += "M";
						} else {
							result += " ";
						}
					}
					result += "\n";
				}

				return result;
			}
			if (ch=='N'||ch=='n'){
				String result = "";
				for (int i = 0; i < 6; i++) {
					for (int j = 0; j < 7; j++) {
						if (j == 0 || j == 6 || j == i) {
							result += "N";
						} else {
							result += " ";
						}
					}
					result += "\n";
				}

				return result;
			}
			if(ch=='O'||ch=='o'){
				String result= "";

				for (int i = 0; i < 5; i++) {
					if (i == 0 || i == 4) {
						result += "O O O\n";
					} else if (i == 1 || i == 3) {
						result += "O   O\n";
					} else {
						result += "O O O\n";
					}
				}
				return result;
			}
			if(ch=='P'||ch=='p'){
				String result = "";
				for (int i =1;i<=num;i++){
					for(int j =1;j<=num;j++){
						if (i==1||j==1||i==(num+1)/2||i==2&&j==num){
							result+="P";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if(ch=='Q'||ch=='q'){
				String result="";
				for(int i=1;i<=num;i++){
					for(int j=1;j<=num;j++){
						if( (i==1&j<=4) || (j==1&i<=4)||(i==4& j<=4) || (j==4&i<=4) ||  (i==j&i>=3)){
							result+=" Q";
						}
						else{
							result+="  ";
						}
					}
					result+="\n";

				}
				return result;
			}
			if(ch=='R'||ch=='r'){
				String result="";
				int k=1;
				for(int i=1;i<=num;i++){
					for(int j=1;j<=num;j++){
						if((i==1&j<=4)||(j==1&j<=6)||(j==4&i<=3)||(i==3&j<=3)||i+j==k){
							result+=" R";
						}
						else{
							result+="  ";
						}	
					}
					result+="\n";
					k=k+2;
				}
				return result;
			}
			if(ch=='S'||ch=='s'){
				String result = "";
				for (int i =1;i<=num;i++){
					for(int j =1;j<=num;j++){
						if (i==1||i==(num/2)+1||i==num||i==2&&j==1||i==4&&j==num){
							result+="S";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if(ch=='T'||ch=='t'){
				String result="";
				for(int i=1;i<=num;i++){
					for(int j=1;j<=num;j++){
						if(i==1 || j==3){
							result+=" T";
						}
						else{
							result+=" .";
						}
					}
					result+="\n";
				}
				return result;
			}
			if(ch=='u'||ch=='U'){
				String result="";
				for(int i=1;i<=num;i++){
					for(int j=1;j<=num;j++){
						if(j==1||i==5||j==5){
							result+=" U";
						}
						else{
							result+="  ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if(ch=='V'||ch=='v'){
				String result = "";
				for (int i =0;i<=(9/2)+1;i++){
					for(int j =0;j<9;j++){
						if (j==(9-i)||j==i-1){
							result+="v";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if(ch=='W'||ch=='w'){
				String result="";
				for(int r=1;r<=num;r++){
					for (int c=1;c<=num;c++){
						if( c==1 || c==num ||(r==c && r>2)|| (r==4 && c==2) ){
							result+="W";
						}
						else {
							result+=" ";
						}
					}result+="\n";
				}
				return result;
			}
			if(ch=='X'||ch=='x'){
				String result="";
				for(int i=1;i<=num;i++){
					for(int j=1;j<=num;j++){
						if((i==1&&j==1)||(i==2&&j==2)||(i==3&&j==3)||(i==4&&j==2)||(i==5&&j==1)||(i==2&&j==4)||(i==1&&j==5)||(i==4&&j==4)||(i==5&&j==5)){
							result+="X";
						}
						else{
							result+=" ";
						}
					}
					result+="\n";
				}
				return result;
			}
			if(ch=='Y'||ch=='y'){
				String result="";
				for(int r=1;r<=num;r++){
					for (int c=1;c<=num;c++){
						if( (r==c && r<=3)||(c==3 && r>3) || (r+c==6 && r<=3)){
							result+="Y";
						}
						else {
							result+=" ";
						}
					}result+="\n";
				}
				return result;
			}
			if(ch=='Z'||ch=='z'){
				String result="";
				for(int r=1;r<=num;r++){
					for (int c=1;c<=num;c++){
						if( r==1 || r==5 || r+c==num){
							result+="Z";
						}
						else {
							result+=" ";
						}
					}result+="\n";
				}
				return result;
			}



			else{
				return "";
			}
		}

	}



