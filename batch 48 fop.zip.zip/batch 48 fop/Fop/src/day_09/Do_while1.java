package day_09;

public class Do_while1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean quit=true; int i=0;
		
		String[] s = new String[]        {"chicken biryani    ","motton biryani","chicken fry piece biyani","chicken dum biryani","motton dum biryani","full meels","mini meels","pepsi","Quit"};
	  int rate []=new int[] {160,230,175,150,250,120,60,25,0};
		int choice;
	 do { 
		 System.out.println("item name "+"      Item price");
		 for(i=0;i<s.length;i++)
		 {    
			 
			 System.out.println((i+1)+"."+s[i]+"        "+rate[i]);
			 
		 }
	 }while(i<s.length);
	}

}
