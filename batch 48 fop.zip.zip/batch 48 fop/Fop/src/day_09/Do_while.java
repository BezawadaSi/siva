package day_09;
import java.util.Scanner;
public class Do_while {

	public static void main(String[] args) {
		boolean quit=true; int i=0;
		String[] s = new String[]        {"idly    ","wada    ","dosa    ","poori     ","pesarattu","uttapam","bonda     ","tea   ","coffee    ","Quit     "};
	 int choice;
	do {
		 System.out.println("itm");
		 for(i=0;i<10;i++)
			 System.out.println((i+1)+"."+s[i]);
		// int choice;
		 Scanner sc = new Scanner(System.in);
		 /*do{
		 System.out.println("Hotel Dummy Bawarchi");
		 System.out.println("1. IDLY");
		 System.out.println("2. POORI");
		 System.out.println("3. DOSA");
		 System.out.println("4. TEA");
		 System.out.println("5. E X I T");*/
		 System.out.println("Enter your choice..: ");
		 choice = sc.nextInt();
		 switch(choice){
		 case 1:
			 System.out.println("Not Available..");
		 
		 break;
		 case 2: System.out.println("Out of Stock...");
		 break;
		 case 3: System.out.println("Making Now...");
		 break;
		 case 4: System.out.println("Milk Broaken..");
		 break;
		 case 5: System.out.println("Thank U Visit Again...");
		 break;
		 default: System.out.println("Check Menu..");
		 }
		 }while(choice!=5);
		 }
		// }
	    //}while(i<10);
}//}