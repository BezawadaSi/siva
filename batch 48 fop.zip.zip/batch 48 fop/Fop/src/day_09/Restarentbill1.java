package day_09;

public class Restarentbill1 {

	
		// TODO Auto-generated method stub
		public static void main(String[] args) {
			Restarent_bill  fo=new Restarent_bill();
			fo.displayMenu();
			fo.order1();
		}

	}


