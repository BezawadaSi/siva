package day_09;
import java.util.Scanner;
public class Restarent_bill {
	  int chicken_biryani =160,chicken_dum_biryani=170,Motton_biryani=200,Shawarma=100,Motton_keema_biryani=220,gongura_chicken_biryani=180,french_fries=120,motton_dum_biryani=220,lassi=60,cock=30;
    int ch,quentity,totalbill=0; String again;
    Scanner sc=new Scanner(System.in);
	 public void displayMenu() {
    	System.out.println("************Welcome to our restarent*************");
    	System.out.println("=================================================");
    	System.out.println("       1. chicken_biryani              160/-");
    	System.out.println("       2. chicken_dum_biryani          170/-");
    	System.out.println("       3. Motton_biryani               200/-");
    	System.out.println("       4. Shawarma                     100/-");
    	System.out.println("       5. Motton_keema_biryani         220/-");
    	System.out.println("       6. gongura_chicken_biryani      180/-");
    	System.out.println("       7. french_fries                 120/-");
    	System.out.println("       8. motton_dum_biryani           220/-");
    	System.out.println("       9. lassi                         60/-");
    	System.out.println("       10.cock                          30/-");
    	System.out.println("       11.exit                              ");
    	System.out.println("=================================================");
    	System.out.println("**** what do you want to order sir /madam ****");
    	System.out.println();
	  }
	  public void generateBill() {
		  System.out.println();
		  System.out.println("******** thank you for ordering*******");
		  System.out.println("********* yor total bill is :"+totalbill+"************");
	 }
	  public void order1() {
		   while(true) {
    	System.out.println("enter your choice ; ");
    	ch=sc.nextInt();
    
    	switch(ch)
    	{
    	case 1:
    	{
    		System.out.println("you have ordered chicken biryani");
    		System.out.println();
    		System.out.println("ehter the how many chicken biryani you want");
    		 quentity = sc.nextInt();
    		totalbill=totalbill+quentity*chicken_biryani;
    		break;
    	}
    	case 2:
    	{
    		System.out.println("you have ordered chicken_dum_biryani ");
    		System.out.println();
    		System.out.println("enter the how many chicken_dum_biryani  you want");
    		 quentity = sc.nextInt();
    		totalbill=totalbill+quentity*chicken_dum_biryani ;
    		break;
    	}
    	case 3:
    	{
    		System.out.println("you have ordered Motton_biryani ");
    		System.out.println();
    		System.out.println("enter the how many Motton_biryani  you want");
    		 quentity = sc.nextInt();
    		totalbill=totalbill+quentity*Motton_biryani ;
    		break;
    	}
    	case 4:
    	{
    		System.out.println("you have ordered Shawarma");
    		System.out.println();
    		System.out.println("enter the how many Shawarma you want");
    		 quentity = sc.nextInt();
    		totalbill=totalbill+quentity*Shawarma;
    		break;
    	}
    	case 5:
    	{
    		System.out.println("you have ordered Motton_keema_biryani ");
    		System.out.println();
    		System.out.println("enter the how many Motton_keema_biryani you want");
    		 quentity = sc.nextInt();
    		totalbill=totalbill+quentity*Motton_keema_biryani ;
    		break;
    	}
    	case 6:
    	{
    		System.out.println("you have ordered gongura_chicken_biryani");
    		System.out.println();
    		System.out.println("enter the how many gongura_chicken_biryani you want");
    		 quentity = sc.nextInt();
    		totalbill=totalbill+quentity*gongura_chicken_biryani;
    		break;
    	}
    	case 7:
    	{
    		System.out.println("you have ordered french_fries");
    		System.out.println();
    		System.out.println("enter the how many french_fries you want");
    		 quentity = sc.nextInt();
    		totalbill=totalbill+quentity*chicken_biryani;
    		break;
    	}
    	case 8:
    	{
    		System.out.println("you have ordered motton_dum_biryani  ");
    		System.out.println();
    		System.out.println("enter the how many  motton_dum_biryani   you want");
    		 quentity = sc.nextInt();
    		totalbill=totalbill+quentity*motton_dum_biryani  ;
    		break;
    	}
    	case 9:
    	{
    		System.out.println("you have ordered lassi");
    		System.out.println();
    		System.out.println("enter the how many lassi you want");
    		 quentity = sc.nextInt();
    		totalbill=totalbill+quentity*chicken_biryani;
    		break;
    	}
    	case 10:
    	{
    		System.out.println("you have ordered cock");
    		System.out.println();
    		System.out.println("enter the how many cock you want");
    		 quentity = sc.nextInt();
    		totalbill=totalbill+quentity*cock;
    		break;
    	}
    	case 11:
    	{
    		System.exit(1);
    		break;
    	}
    	default:
    		break;
    		
    	}
    	System.out.println();
    	System.out.println(" Do you wish to order anything  sir/madam else4(Y/N)");
    	again=sc.next();
    	if(again.equalsIgnoreCase("Y"))
    	{
    		order1();
    	}
    	else if(again.equalsIgnoreCase("N"))
    	{
    		generateBill();
    	System.exit(2);
    	}
    	else {
    		System.out.println("invalid choice");
    	}
    	}
	}

	public static void main(String[] args) {
		Restarent_bill  siva=new Restarent_bill();
		siva.displayMenu();
		siva.order1();
	}

}
