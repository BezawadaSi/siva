package day_13;

import java.io.Serializable;
	import java.util.ArrayList;
	import java.util.List;

	public class ShoppingCart implements Serializable {
	    private static final long serialVersionUID = 1L;

	    private List<Product> cartItems;

	    public ShoppingCart() {
	        cartItems = new ArrayList<>();
	    }

	    public void addItem(Product product) {
	        cartItems.add(product);
	    }

	    public void displayCartItems() {
	        if (cartItems.isEmpty()) {
	            System.out.println("Your cart is empty.");
	        } else {
	            System.out.println("Your cart items:");
	            for (Product product : cartItems) {
	                System.out.println(product.getName() + " - Rs" + product.getPrice());
	            }
	        }
	    }

	    
	    public double calculateTotal() {
	        double total = 0;
	        for (Product product : cartItems) {
	            total += product.getPrice();
	        }
	        return total;
	    }
	}

