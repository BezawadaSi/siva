package day_13;


import java.util.List;
import java.util.Scanner;

public class Main {
    private static User currentUser;
    private static ShoppingCart cart;

    public static void main(String[] args) {
        // Load users and products from files
        List<User> users = ProductManager.loadUsers();
        List<Product> products = ProductManager.loadProducts();

        if (users == null) {
            // Initialize some sample users (remove this in a real application)
            users = List.of(new User("user1", "pass1"), new User("user2", "pass2"));
        }

        if (products == null) {
            // Initialize some sample products (remove this in a real application)
            products = List.of(
                new Product(1, "Laptop", 199999.99),
                new Product(2, "Smartphone", 129999.09),
                new Product(3, "Headphones", 60000.29),
                new Product(4, "Tablet", 80000.69),
                new Product(5, "Smartwatch", 50000.89)
            );
        }

        // Initialize the shopping cart
        cart = ProductManager.loadCart();
        if (cart == null) {
            cart = new ShoppingCart();
        }

        // Main menu
        Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\n=== MANGO ===");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. View Products");
            System.out.println("4. Add Product to Cart");
            System.out.println("5. View Cart");
            System.out.println("6. Calculate Total");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    registerUser(scanner, users);
                    break;
                case 2:
                    loginUser(scanner, users);
                    break;
                case 3:
                    viewProducts(products);
                    break;
                case 4:
                    addProductToCart(scanner, products);
                    break;
                case 5:
                    viewCart();
                    break;
                case 6:
                    calculateTotal();
                    break;
                case 0:
                    // Save users, products, and cart to files before exiting
                    ProductManager.saveUsers(users);
                    ProductManager.saveProducts(products);
                    ProductManager.saveCart(cart);
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 0);

        scanner.close();
    }

    private static void registerUser(Scanner scanner, List<User> users) {
        System.out.print("Enter your username: ");
        String username = scanner.next();

        for (User user : users) {
            if (user.getUsername().equals(username)) {
                System.out.println("Username already exists. Please choose a different username.");
                return;
            }
        }

        System.out.print("Enter your password: ");
        String password = scanner.next();

        User newUser = new User(username, password);
        users.add(newUser);
        currentUser = newUser;

        System.out.println("User registered successfully!");
    }

    private static void loginUser(Scanner scanner, List<User> users) {
        if (currentUser != null) {
            System.out.println("You are already logged in as " + currentUser.getUsername());
            return;
        }

        System.out.print("Enter your username: ");
        String username = scanner.next();

        System.out.print("Enter your password: ");
        String password = scanner.next();

        for (User user : users) {
            if (user.getUsername().equals(username) && user.isPasswordCorrect(password)) {
                currentUser = user;
                System.out.println("Login successful! Welcome, " + currentUser.getUsername() + "!");
                return;
            }
        }

        System.out.println("Invalid username or password.");
    }

    private static void viewProducts(List<Product> products) {
        System.out.println("=== Available Tech Products ===");
        for (Product product : products) {
            System.out.println(product.getId() + ". " + product.getName() + " - Rs" + product.getPrice());
        }
    }

    private static void addProductToCart(Scanner scanner, List<Product> products) {
        if (currentUser != null) {
            viewProducts(products);
            System.out.print("Enter the product ID to add to cart: ");
            int productId = scanner.nextInt();

            Product selectedProduct = null;
            for (Product product : products) {
                if (product.getId() == productId) {
                    selectedProduct = product;
                    break;
                }
            }

            if (selectedProduct != null) {
                cart.addItem(selectedProduct);
                System.out.println(selectedProduct.getName() + " added to cart.");
            } else {
                System.out.println("Invalid product ID.");
            }
        } else {
            System.out.println("Please register and login before adding products to the cart.");
        }
    }

    private static void viewCart() {
        if (currentUser != null) {
            System.out.println("=== " + currentUser.getUsername() + "'s Cart ===");
            cart.displayCartItems();
        } else {
            System.out.println("Please register and login to view the cart.");
        }
    }

    private static void calculateTotal() {
        if (currentUser != null) {
            System.out.println("=== " + currentUser.getUsername() + "'s Cart Total ===");
            double total = cart.calculateTotal();
            System.out.println("Total: Rs" + total);
        } else {
            System.out.println("Please register and login to view the cart total.");
        }
    }
}
