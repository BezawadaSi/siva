package day_13;
import java.io.*;
import java.util.List;

public class ProductManager {
    private static final String PRODUCTS_FILE_PATH = "d:/products.dat";
    private static final String USERS_FILE_PATH = "d:/users.dat";
    private static final String CART_FILE_PATH = "d:/cart.dat";

    public static void saveProducts(List<Product> products) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(PRODUCTS_FILE_PATH))) {
            oos.writeObject(products);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Product> loadProducts() {
        List<Product> products = null;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(PRODUCTS_FILE_PATH))) {
            products = (List<Product>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return products;
    }

    public static void saveUsers(List<User> users) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(USERS_FILE_PATH))) {
            oos.writeObject(users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<User> loadUsers() {
        List<User> users = null;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(USERS_FILE_PATH))) {
            users = (List<User>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return users;
    }

    public static void saveCart(ShoppingCart cart) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(CART_FILE_PATH))) {
            oos.writeObject(cart);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ShoppingCart loadCart() {
        ShoppingCart cart = null;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(CART_FILE_PATH))) {
            cart = (ShoppingCart) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return cart;
    }
}