package day_08_assignments;
import java.util.Scanner;
public class Program_17 {
	public static void main(String args[]) {

		System.out.println(get_values(496));
	System.out.println(get_values(28));
	}  
	public static String get_values(int n) {
		int i=1; int sum=0;
		String result="";
	while(i <= n/2)  
	{  
	if(n % i == 0)  
	{  
  
	sum = sum + i; 
	}  
	i++;  
	}  
	if(sum==n)  
	{  
	
	result=n+" is a perfect number.";  
	} 
	else  {
	
	result=n+" is not a perfect number.";
	}
	return result;
	} 

	}
