package day_08_assignments;

public class Program_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  System.out.println(get_number(100));
  System.out.println(get_number(5));
	}
  public static int get_number(int num)
  { int sum=0;
	  for(int i=1;i<=num;i++)
	  {
		  sum= sum+i;
	  }
	 return sum; 
  }
}
