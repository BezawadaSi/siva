package day_08_assignments;

public class Program_13 {

	public static void main(String[] args) {
		System.out.println(get_value(1,100));

	}
public static String get_value(int start ,int end)
{ String result="";
int sum=0;
	for (int i=start;i<=end;i++)
	{
		if((i%3==0)||(i%5==0))
		{
			System.out.println("divisible of 3 or 5 : "+i);
		sum=sum+i;	
		}
	}
	result="the sum of all numbers divisible by 3 or 5 between  "+start+"and "+end+"is "+sum;
	return result;}

}
