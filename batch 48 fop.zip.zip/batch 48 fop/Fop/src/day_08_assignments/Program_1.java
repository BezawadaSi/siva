package day_08_assignments;


public class Program_1 {
    public static void main(String[] args)
    {
        System.out.println(get_number(9));
    }   
    public static String get_number(int N)
{
     
    	String result="";
 
        for (int i = 1; i <= 10; i++) {
           System.out.println(N + " * " + i + " = "+ N * i);
        }
        return result ;
}   
   
}