package day_08_assignments;

public class Program_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(get_number(5));

	}
   
	public static int get_number(int num)
	{
		int sum=0;
		int i=2;
		while(i<=num*2)     // for (int i = 2; i <= 2 * n; i += 2)     //even =n*n;
		{                                                              // odd=n(n+1)
			sum=sum+i;
			i+=2;
		}
	return sum;
	}
}
