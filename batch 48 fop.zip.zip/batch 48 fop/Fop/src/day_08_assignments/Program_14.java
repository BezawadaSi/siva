package day_08_assignments;

public class Program_14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  System.out.println(get_spy(123));
  System.out.println(get_spy(623));
	}
 public static String get_spy(int num)
 { 
	 String result="";
	 int sum=0,product=1;
	 while(num>0)
	 {
		 sum=sum+num%10; 
		product=product*(num%10);
		num=num/10;
	 }
	if(sum==product)
	{
		result="given number is spy number ";
	}
	else
	{
		result="given number is not spy number ";
	}
	return result;
 }
}
