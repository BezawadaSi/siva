package day_08_assignments;
import java.util.Scanner;
public class Program_5 {

	public static void main(String[] args) {
		
      System.out.println(get_number(8));
	}
  public static int get_number(int num)
  {
	  int i=1;                        
	 int product = 1, limit;
		Scanner sc = new Scanner(System.in);
		System.out.println("Calculates Product of first n numbers");
		System.out.println("*-----*-----*-----*------*-----*------*------*");
		System.out.print("Enter limit number:");
		limit = sc.nextInt();
		while(i<=limit) {
			product *= i;
			i++;}
	  
    return product; } 
}
 
