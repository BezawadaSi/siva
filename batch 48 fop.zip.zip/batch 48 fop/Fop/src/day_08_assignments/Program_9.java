package day_08_assignments;

public class Program_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(get_Palindrome(454));
System.out.println(get_Palindrome(4554));
System.out.println(get_Palindrome(56478));
	}
  public static String get_Palindrome(int num)
  {  
	  String result;
	 int r,sum=0;               
	 int temp=num;              
	 while(num>0)    
	 {             
	 r=num%10;    
	 sum=(sum*10)+r; 
	 num=num/10;     
	}
	 result="origianl number is :"+ temp+"\n after reveresing the number is :"+sum;
	  
	  
	  
	return result;  
  }
}
