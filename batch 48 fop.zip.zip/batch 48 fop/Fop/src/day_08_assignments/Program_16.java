package day_08_assignments;

public class Program_16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  System.out.println(get_value(153));
  System.out.println(get_value(9874));
  System.out.println(get_value(371));
	}
public static String get_value(int num)
{   String result; int count=0;
	int temp=num;
	int sum=0;
	while(temp>0)
	{
		temp=temp/10;
		count++;
	}
	temp=num;
	while(temp>0)
	{   int digit=temp%10;
		sum=sum+(int)Math.pow(digit, count);
		temp=temp/10;
	}
   if(num==sum)
   {
	   result="given  number is amstrong.";
   }
   else {
	   result="given number is not amstrong.";
   }
   return result;
}
}
