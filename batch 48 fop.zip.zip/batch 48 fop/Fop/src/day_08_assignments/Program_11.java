package day_08_assignments;

public class Program_11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  System.out.println(get_answer(2345678));
  System.out.println(get_answer(23456786));
	}
public static String get_answer(int num)
{ int r;
String result="";
	while(num>0)
	{
		r=num%10;
		if(r%2==0)
		{
			System.out.println(r);
		}
		num/=10;
	}
		return result;}
}
