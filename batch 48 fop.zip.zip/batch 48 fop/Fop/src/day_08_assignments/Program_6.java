package day_08_assignments;

public class Program_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 System.out.println(get_value(5));
 System.out.println(get_value(8));

	}
public static String  get_value(int num)
{   String result="";
	int b,count=0;
	for (b=1;b<=num;b++)
			{
		if(num%b==0)
			count++;
			}
	if(count==2)
	{
		System.out.println("given number is prime ");
	}
	else 
	{
		System.out.println("given number is not prime");
	}
	return result ;
}
} 
