package day_08_assignments;

public class Program_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  System.out.println(get_number(5));
	}
  public static int get_number(int num)
  { int sum=0;
	  
  for(int i=1;i<num*2;i+=2)        //for(int i=1;i<=num*2;)                for(i=1;i<n;i++)
	  {   
                                   //{
	sum= sum+i;                    //    sum=sum+i;                          sum=sum=i*2-1;
	//i=i+2;                       // i=i+2;
		
	  }
	 return sum; 
  }
}
