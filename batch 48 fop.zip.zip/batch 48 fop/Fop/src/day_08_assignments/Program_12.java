package day_08_assignments;

public class Program_12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(get_Palindrome(454));
System.out.println(get_Palindrome(4554));
	}
  public static String get_Palindrome(int num)
  {
	 int r,sum=0;   
	 int temp=num;   
	 while(num>0)    
	 {             
	 r=num%10;     
	 sum=(sum*10)+r; 
	 num=num/10;     
	 }
	 return (temp==sum)?"palimdrome":"not palimdrome";  // res2+res4+res6
	  
	  
	  
	  
  }
}
