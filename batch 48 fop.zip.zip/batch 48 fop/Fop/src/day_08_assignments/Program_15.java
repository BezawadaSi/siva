package day_08_assignments;

public class Program_15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  System.out.println(get_number(18));
  System.out.println(get_number(188));
	}
 public static int get_number(int num)
 { 
	 while (num != 1) {
         System.out.print(num + " ");
         if (num % 2 == 0) {
             num /= 2;
         } else {
             num = num * 3 + 1;
         }
     }
     return num;
 }
 }

