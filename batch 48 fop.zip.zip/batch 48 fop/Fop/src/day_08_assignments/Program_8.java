package day_08_assignments;

public class Program_8 {

	public static void main(String[] args) {  
		// TODO Auto-generated method stub
 System.out.println(get_value(454));
 System.out.println(get_value(6789));
	}
 public static String get_value(int num)
 {
	 
	 String result="";
	 int r;
	 for(int i=1;i<=num;i++)
	 {
		 r= num%10;
		 System.out.println(r);
		 num=num/10;
	 }
	 return result;	 
 }
 
}
/*


while(n>0)  
{   
n=n/10;  
count++;  
}   
while(temp > 0)  
{  
digit=temp%10;   
System.out.println("Digit at place "+count+" is: "+digit);  
temp=temp/10;
count--;  
*/