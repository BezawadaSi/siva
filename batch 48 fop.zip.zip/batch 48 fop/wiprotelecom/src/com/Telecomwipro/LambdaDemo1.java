package com.Telecomwipro;

//package com.wipro.interfaceapps;


@FunctionalInterface
interface Arith1{
	int op(int a,int b);
}
public class LambdaDemo1 {
	public static void main(String[] args) {
		Arith1 ar=(a,b)->a+b;
		System.out.println(ar.op(5, 6));
		Arith1 ar1=(a,b)->a*b;
		System.out.println(ar1.op(5, 6));
	}
}