package com.Telecomwipro;

//package com.wipro.interfaceapps;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
 
@FunctionalInterface
interface Arith2{
	int op(int a,int b);
}
public class LambdaDemo2 {
	public static void main(String[] args) {
		Arith1 ar=(int a,int b)-> { return a+b; }; // (a,b)->a+b;
		System.out.println(ar.op(5, 6));
		Arith1 ar1=(a,b)->a*b;
		System.out.println(ar1.op(5, 6));
		//Consumer, Supplier, Predicate,Function
		Supplier<Integer> s=()-> 99;
		System.out.println(s.get());
		Consumer<Integer> c=(a)->System.out.println(a*a*a);
		c.accept(6);
		Predicate<Integer> p=(a)->a%2==0;
		System.out.println(p.test(4));
		Function<Integer,Integer> f=(a)->a*a;
		System.out.println(f.apply(8));
	}
}
