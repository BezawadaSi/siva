package com.wipro.io;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        try {
            ProductManagerJDBC manager = new ProductManagerJDBC("jdbc:oracle:thin:@localhost:9501/XE\",\"system\",\"rps@123\r\n"
            		+ "");
            
            // Create the table
            manager.createProductTable();  

            // ... (rest of your product management operations) ...

            manager.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

