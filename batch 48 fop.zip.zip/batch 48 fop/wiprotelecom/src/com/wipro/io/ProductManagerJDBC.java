package com.wipro.io;

import java.sql.*;

public class ProductManagerJDBC {
    private Connection connection;
	private String user;
	private String password;

    public ProductManagerJDBC(String url) throws SQLException {
        this.connection = DriverManager.getConnection(url, user, password);
    }

    public void createProductTable() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS product (" +
                     "product_id INT PRIMARY KEY," +
                     "name VARCHAR(255)," +
                     "price DECIMAL(10, 2)," +
                     "quantity INT" +
                     ")";
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(sql);
            System.out.println("Product table created (if not existing)");
        }
    }

    public void addProduct(int productId, String name, double price, int quantity) throws SQLException {
        String sql = "INSERT INTO product (product_id, name, price, quantity) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, productId);
            pstmt.setString(2, name);
            pstmt.setDouble(3, price);
            pstmt.setInt(4, quantity);
            pstmt.executeUpdate();
            System.out.println("Product added: " + name);
        }
    }

    public void deleteProduct(int productId) throws SQLException {
        String sql = "DELETE FROM product WHERE product_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, productId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Product deleted with ID: " + productId);
            } else {
                System.out.println("Product not found with ID: " + productId);
            }
        }
    }

    public void updateProduct(int productId, String newName, double newPrice, int newQuantity) throws SQLException {
        String sql = "UPDATE product SET name = ?, price = ?, quantity = ? WHERE product_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, newName);
            pstmt.setDouble(2, newPrice);
            pstmt.setInt(3, newQuantity);
            pstmt.setInt(4, productId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Product updated with ID: " + productId);
            } else {
                System.out.println("Product not found with ID: " + productId);
            }
        }
    }

    public void listProducts() throws SQLException {
        String sql = "SELECT * FROM product";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (!rs.next()) {
                System.out.println("No products found.");
                return;
            }

            System.out.println("Product List:");
            do {
                int id = rs.getInt("product_id");
                String name = rs.getString("name");
                double price = rs.getDouble("price");
                int quantity = rs.getInt("quantity");
                System.out.println(id + " - " + name + ", Price: $" + price + ", Quantity: " + quantity);
            } while (rs.next());
        }
    }

    // Close the connection when done
    public void close() throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }
}



// ... (rest of the ProductManagerJDBC class code) ...

    